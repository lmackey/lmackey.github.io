function q = gramSchmidt(w, Q, numVecs, epsilon)
%GRAMSCHMIDT    Gram-Schmidt projection.
%   q = GRAMSCHMIDT(w, Q, numVecs) returns the L2-normalized projection of
%   w onto the orthocomplement of the space spanned by columns 1:numVecs of
%   Q.  The procedure assumes columns 1:numVecs of Q have L2 norm 1.
%
%   q = GRAMSCHMIDT(w, Q, numVecs, epsilon) returns the all zero vector if
%   the L2 norm of the projection is smaller than epsilon.  Epsilon = 1e-6
%   by default.
%

% Author: Lester Mackey, University of California, Berkeley

if nargin < 4
    epsilon = 1e-6; % Numerical precision threshold
end

% Modified Gram-Schmidt: Use this version for greater numerical stability
q = w;
for i = 1:numVecs
    q = q - Q(:,i)*(Q(:,i)'*q);
end
nm = norm(q);
if(nm > epsilon)
    q = q/nm;
else
    q = 0;
end

% Classic Gram-Schmidt: This version is supposedly numerically unstable
% This version further assumes orthogonality of Q columns
% q = w - Q(:,1:numVecs)*Q(:,1:numVecs)'*w;
% nm = norm(q);
% if(nm > epsilon)
%     q = q/nm;
% else
%     q = 0;
% end
