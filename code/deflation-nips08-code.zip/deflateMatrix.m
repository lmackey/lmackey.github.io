function[A, Q, B] = deflateMatrix(A, w, defMode, Q, nPC, B)
%DEFLATEMATRIX  Single vector matrix deflation.
%   A = DEFLATEMATRIX(A, w, defMode) deflates the symmetric matrix A
%   with respect to pseudo-eigenvector w, using the deflation technique
%   specified by defMode.
%
%   Valid values of defMode:
%       'hd' -> Hotelling's deflation
%       'pd' -> Projection deflation
%       'scd' -> Schur complement deflation
%       'ohd' -> Orthogonalized Hotelling's deflation
%       'opd' -> Orthogonalized projection deflation
%       'gevd' -> Generalized deflation
%
%   [A, Q] = DEFLATEMATRIX(A, w, defMode, Q, nPC) additionally
%   extends the orthonormal basis in Q by projecting w onto the
%   orthocomplement of the space spanned by columns 1:(nPC-1) of Q and
%   adding the projection as the nPC-th column of Q.  
%   Note: Generalized deflation and all orthogonalized deflation methods 
%   require the orthonormal basis Q for deflation.
%
%   [A, Q, B] = DEFLATEMATRIX(A, w, 'gevd', Q, nPC, B) takes in the
%   supplementary matrix of generalized deflation and outputs the deflated
%   version of this matrix.  On first call, B should equal eye(size(A)).

% Author: Lester Mackey, University of California, Berkeley
% Reference: 'Deflation Methods for Sparse PCA' by Lester Mackey, 
% Advances in Neural Information Processing Systems 21, 2008.

if nargin > 4
    % Extend orthonormal basis in fashion of Gram-Schmidt decomposition
    Q(:,nPC) = gramSchmidt(w, Q, nPC-1);
end

switch defMode

    case 'hd'
        % Perform Hotelling's deflation
        % A_(n+1) := A_n - ww'A_nww'
        A = A - w*(w'*A*w*w');

    case 'pd'
        % Perform projection deflation:
        % A_(n+1) := A_n - A_nww' - ww'A_n + ww'A_nww' = (X_n - X_nww')^2
        %          = (I - ww')*A_n*(I - ww')
        A_wwt = A*w*w';
        A = A - A_wwt - A_wwt' + w*(w'*A_wwt);

    case 'scd'
        % Perform Schur complement deflation
        % A_(n+1) := A_n - A_nw((w'A_nw)^-1)w'A_n = A_n - A_nww'A_n/(w'A_nw)
        A_w = A*w;
        A = A - A_w*A_w'/(w'*A_w);

    % The remaining deflation options require an orthogonal basis, Q,
    %   for the W vectors

    case 'ohd'
        % Perform orthogonalized Hotelling's deflation 
        % A_(n+1) := A_n - qq'A_nqq'
        A = A - Q(:,nPC)*(Q(:,nPC)'*A*Q(:,nPC)*Q(:,nPC)');

    case 'opd'
        % Perform orthogonalized projection deflation
        % A_(n+1) := A_n - A_nqq' - qq'A_n + qq'A_nqq' 
        %          = (I - qq')*A_n*(I - qq')
        A_qqt = A*Q(:,nPC)*Q(:,nPC)';
        A = A - A_qqt - A_qqt' + Q(:,nPC)*(Q(:,nPC)'*A_qqt);

    case 'gevd'
        % Perform generalized deflation
        % B_(n+1) := B_n(I - qq') 
        %          = (I - QQ')
        % A_(n+1) := A_n - A_nqq' - qq'A_n + qq'A_nqq' 
        %          = (I - qq')*A_n*(I - qq') = (I - QQ')*A_n*(I - QQ')
        %          = B_(n+1)*A_n*B_(n+1)
        B = eye(size(A,1)) - Q(:,1:nPC)*Q(:,1:nPC)'; % symmetric
        A = B*A*B;

end