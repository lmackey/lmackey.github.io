function bnbp(data,K,opts)
% BNBP Performs MCMC posterior inference under a beta negative binomial
% process prior and a Gaussian likelihood
%
% Example Usage:
%  opts=struct('do_print',true); 
%  bnbp(data,K,opts);
%
% data : structure defining the following fields
% -Xid : Each cell is a document containing observations as columns.
% -Xcnt : Ignored.
% -*_train : training data
% -*_test : testing data
%
% K : Number of starting topics.
%
% opts : an options structure defining the following fields
% -log_xi_base : Base value determining xi slice sampling sequence (see
%                compute_log_xi.m or max_xi_index.m)
% -save_step : How many MCMC iterations between saves; default 1
% -save_file : Where to save the MCMC samples; default 'bnb_samps_inf.mat'
% -do_print : true to print iteration summaries; default false
% -do_plot : true to plot summaries; default false

% Set default options
opts = set_default_opts(opts);
% Extract options
global log_xi_base;
[log_xi_base,save_step,save_file,do_print,do_plot]=get_opts(opts);

% Number of documents
D = length(data.Xid_train);
assert(D==1,'data.Xid_train should contain exactly one document');
% Number of observations
M = size(data.Xid_train{1},1);
% Observation length
V = size(data.Xid_train{1},2);
% Prior parameters for normal distribution over topic-observation
% parameters
mu0 = 0;
sigma_sqd0 = 1;
% Variance of each observation entry
sigma_sqd = 1;
% Sufficient statistics for estimating normal distribution over
% topic-observation parameters
suff_stats = zeros(K,V+1);
% Topic counts
N = zeros(K,D);
% Maximum candidate topic for the next round of sampling for each instance
% of each word in each document.
% Z{d}{i} is an array of maximum candidate topics.
Z = cell(1,D);
for d = 1:D
    Z{d} = cell(1,length(data.Xid_train{d}));
    for i = 1:length(data.Xid_train{d})
        % Treat K as the maximum candidate across all documents
        Z{d}{i} = K;
    end
end

% Feature probabilities
p = ones(K,1)/K;
% Prior parameters for the top-level mu distribution
c0 = 3;
gamma0 = 3;
% Failure parameters for document negative binomial distributions
r = M*(c0-1)/(c0*gamma0);

ite = 0; % Iteration counter
bool = 1;
while bool
    ite = ite + 1;
    tic;
    %% Sample topic assignments Z, compute topic counts by document N,
    % update posterior topic-observation parameters suff_stats, and update
    % maximum candidate topics K
    [N,Z,K,suff_stats] = ...
        samp_topics_gsn(data,mu0,sigma_sqd0,sigma_sqd,p,r,N,Z,K,suff_stats,opts);
    
    %% Eliminate unused topics
    unused = N == 0;
    suff_stats(unused,:) = [];
    N(unused,:) = [];
    % Maximum topic used
    K_used = length(N);
    
    %% Sample feature weights of used topics
    p = betarnd(N, c0 + r);

    %% Prepare new topics for next round of sampling
    if K_used < K
        % Expand N if necessary
        N(K,:) = 0;
        % Initialize sufficient statistics for new topics
        suff_stats((K_used+1):K,:) = 0;
        % Range of rounds to consider: [m_start, m_start+m_range-1)
        m_start = 0; 
        m_range = 1;
        while length(p) < K            
            % Cumulative sum of Poisson parameters for rounds 
            % [m_start, m_start+m_range-1]
            cumparams = cumsum(c0*gamma0./...
                (c0+(m_start:(m_start+m_range-1))+r));
            % Number of new features from these rounds
            C = poissrnd(cumparams(end));
            if C > 0
                % Sample a specific round for each new feature
                ms = sort(arrayfun(@(x) find(x < cumparams,1),...
                    rand(C,1)*cumparams(end)));
                % Add the features from the earliest rounds to p
                p = [p; betarnd(1, ...
                    c0 + ms(1:min(K-length(p),length(ms)),:) + r)];
                % Update round range start
                m_start = m_start+m_range;
            else
                % Update round range start
                m_start = m_start+m_range;
                % Expand round range
                if m_range < 100000
                    m_range = m_range*10;
                end
            end
        end
        display(m_start+m_range);
    end
    
    %% M-H for r
    %r = samp_r_mh(r, c, N, p, p);

    %% M-H for c_d
    %c = samp_c_mh(c, r, N, p, p);
    
    %% Iteration summary
	time(ite) = toc;
    used_topics(ite) = K_used;

	% print summary
	if do_print
	    fprintf('Iter %d:\n',ite);
	    fprintf('\telapsed time=%f s\n', time(ite));
	    fprintf('\tnum topics used=%d\n',K_used);
	    fprintf('\tmax candidate topic=%d\n',K);
	    fprintf('\ttopic counts: ');
	    fprintf('%d ',N(1:K_used));fprintf('\n');
    end

    %% General plotting setup
	if do_plot
        plot_sample(N,V,ite,suff_stats,c0,[],p,r,opts);
	end

    %% MCMC sample tracking: no special saving needed; just save everything
	% only save every save_step number of steps
	if(mod(ite,save_step) == 0)
		tic;
		save(save_file,'-v7.3');
		time_save = toc;
		if do_print
			fprintf('\tTime spent saving: %f s\n', time_save);
		end
	end
end

function [log_xi_base,save_step,save_file,do_print,do_plot]=...
    get_opts(opts)
% GET_OPTS For each valid opts field, returns the value contained in opts.
log_xi_base = opts.log_xi_base;
save_step = opts.save_step;
save_file = opts.save_file;
do_print = opts.do_print;
do_plot = opts.do_plot;

function opts = set_default_opts(opts)
% SET_DEFAULT_OPTS Assigns a default value to each option not specified in
% opts
default.log_xi_base = log(1.5);
default.collapse_beta = false;
default.collapse_pd_for_p0 = false;
default.collapse_pd_for_z = false;
default.save_step = 1;
default.save_file = 'bnbp_samps_inf.mat';
default.do_print = false;
default.do_plot = false;
for option = fieldnames(default).'
    option = option{1};
    if ~isfield(opts, option)
        opts(1).(option) = default.(option); 
    end
end