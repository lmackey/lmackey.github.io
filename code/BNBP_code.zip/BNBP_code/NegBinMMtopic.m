function NegBinMMtopic(data,K0,opts)
% NEGBINMMTOPIC Performs MCMC inference for the negative binomial topic
% model
%
% Example Usage:
%  K0=200; 
%  opts=struct('save_step',4,'save_file','WITS_bnb_samps_inf.mat', ...
%              'do_print',true,'collapse_pd_for_p0',true); 
%  NegBinMMtopic(data,K0,opts);
%
% data : structure defining the following fields
% -Xid : Word index values. Each cell is a document and contains a
%       sequence of word indices.
% -Xcnt : Word count values. Each cell corresponds to one in Xid.
%        Xcnt{d}(n) counts the number of times word Xid{d}(n) appears in
%        document d.
% -*_train : training data
% -*_test : testing data
%
% K0 : Upper bound on the largest topic index that will ever be
%      considered.
%
% opts : an options structure defining the following fields
% -log_xi_base : Base value determining xi slice sampling sequence (see
%                compute_log_xi.m or max_xi_index.m)
% -collapse_beta : When true, atom locations beta_k are integrated out;
%                  by default, beta_k is sampled explicitly
% -collapse_pd_for_p0 : When true, document level topic weights p_dk are
%                       integrated out when sampling p0;
%                       by default, p_dk is sampled explicitly
% -collapse_pd_for_z : When true, document level topic weights p_dk are
%                      integrated out when sampling z;
%                      by default, p_dk is sampled explicitly
% -calc_perpl : true to calculate perplexity; default true
% -burn_in : Number of MCMC burn-in iterations (will not count
%           for perplexity); default 0
% -perpl_step : Number of MCMC iterations to wait between updating
%              the perplexity calculations; default 1
% -save_step : How many MCMC iterations between saves; default 1
% -save_file : Where to save the MCMC samples; default 'bnb_samps_inf.mat'
% -do_print : true to print iteration summaries; default false
% -do_plot : true to plot summaries; default false


% Set default options
opts = set_default_opts(opts);
global log_xi_base;
% Extract options
[log_xi_base,collapse_beta,collapse_pd_for_p0,collapse_pd_for_z,...
    calc_perpl,burn_in,perpl_step,save_step,save_file,do_print,do_plot]=...
    get_opts(opts);
% OR of collapse pds
collapse_pd_any = collapse_pd_for_z || collapse_pd_for_p0;

% Number of documents
D = length(data.Xid_train);
% Vocabulary size (determined by largest training word index)
V = max(cellfun(@max, data.Xid_train));
% Prior parameter for Dirichlet distribution over topic-word parameters
%beta0 = 1; % Used for exploratory WITS experiment
beta0 = .1; % Used for WITS2 group identification
% Posterior parameters for Dirichlet distribution over topic-word
% parameters
beta_post = beta0 + zeros(K0,V);
% Topic counts for each document
N = zeros(K0,D);
if collapse_pd_any || collapse_beta
    % Topics assigned to each instance of each word in each document.
    % Z{d}{i} is an array of Xcnt_train{d}(i) topics.
    Z = cell(1,D);
    % Maximum topic currently used by each document
    K_used = ones(1,D);
    for d = 1:D
        Z{d} = cell(1,length(data.Xid_train{d}));
        for i = 1:length(data.Xid_train{d})
            topic = 1;
            num_words = data.Xcnt_train{d}(i);
            Z{d}{i} = repmat(topic,num_words,1);
            % Update topic counts
            N(topic, d) = N(topic, d) + num_words;
            % Update word-topic counts
            word = data.Xid_train{d}(i);
            beta_post(topic, word) = beta_post(topic, word) + num_words;
        end
        K_used(d) = find(N(:,d),1,'last');
    end
    % Maximum candidate topic for each document in the next round of sampling
    K = K_used;
else
    K_used = [];
    % Maximum candidate topic for the next round of sampling for each instance
    % of each word in each document.
    % Z{d}{i} is an array of Xcnt_train{d}(i) maximum candidate topics.
    Z = cell(1,D);
    % Maximum candidate topic for each document in the next round of sampling
    K = ones(1,D);
    for d = 1:D
        Z{d} = cell(1,length(data.Xid_train{d}));
        for i = 1:length(data.Xid_train{d})
            max_topic = 1;
            Z{d}{i} = repmat(max_topic,data.Xcnt_train{d}(i),1);
            K(d) = max(K(d), max(Z{d}{i}));
        end
    end
end

% Initialize struct for perplexity calculations
if calc_perpl
    % Will hold the summands in the log perplexity for each document
    lper_d = NaN(D,1);
    % Number of samples used for the perplexity calculation
    Nperpl = 0; 
    % Number of words in the test corpus
    Nwords_test = sum(cellfun(@sum,data.Xcnt_test));
end

% Top-level feature probabilities
p0 = ones(K0,1)/K0;
% Prior parameters for the top-level beta distribution
c0 = 3;
gamma0 = 3;
% Failure parameters for document negative binomial distributions
r = cellfun(@sum, data.Xcnt_train)*(c0-1)/(c0*gamma0);
% Group level feature probabilities
if collapse_pd_for_z && collapse_pd_for_p0
    p = [];
else
    p = .5*ones(K0,D);
end
% Group level feature probability parameters
c = 10*ones(1,D);

% Atom round differences: h(k) = m(k) - m(k-1)
h = zeros(K0,1);

S = 75;
sig2 = 10^-4;

ite = 0; % Iteration counter
while ite < 10000
    ite = ite + 1;
    tic;
    % Sample topic assignments Z, compute topic counts by document N,
    % update posterior topic-word parameters beta_post, and update maximum
    % candidate and used topics K and K_used
    if calc_perpl && (ite > burn_in) && (mod(ite-burn_in,perpl_step)==0)
        % Additionally update test perplexity
        Nperpl = Nperpl + 1;
        [N,Z,K,K_used,beta_post,lper_d] = ...
            samp_topics(data,beta0,p0,p,r,c,N,Z,K,K_used,beta_post,lper_d,opts);
    else
        [N,Z,K,K_used,beta_post] = ...
            samp_topics(data,beta0,p0,p,r,c,N,Z,K,K_used,beta_post,[],opts);      
    end
    
    % Check that candidate topic limit has not been exceeded
    max_K = max(K);
    if max_K > K0
        error(['Candidate topic limit exceeded (%d > %d)!' ...
               'Please run with larger K0.'],max_K, K0);
    end
    % Increase the dimension of beta posterior if necessary
    if max_K > size(beta_post,1)
        beta_post(size(beta_post,1)+1:max_K,:) = beta0;
    end
    
    % Compute round indicators from round differences
    m = cumsum(h);
    
    if ~collapse_pd_for_p0 || ~collapse_pd_for_z
        % Sample group level feature probabilities
        p = betarnd(p0*c + N,(1-p0)*c + repmat(r,K0,1));
    end
    
    % Sample top level beta random variables
    if collapse_pd_for_p0
        p0 = samp_p0_mh_constant_c(p0, S, sig2, N, r, c(1), c0, gamma0, [], m);
    else
        p0 = samp_p0_mh_constant_c(p0, S, sig2, N, r, c(1), c0, gamma0, p, m);
    end

    %% Ordered atom round sampling
    % Select maximum candidate round difference for each atom
    H = max_round_diff(h, p0);
    
    % Store round of previous atom
    last_round = 0;
    % Store number of atoms in last round
    last_round_count = 0;
    % Sample round difference for each atom
    for k = 1:K0
        % Sample a new round difference
        h(k) = sample_round_diff(H(k),last_round,last_round_count,c0, ...
            gamma0);
        if h(k) == 0
            % Sampled the last round
            % Update the count of atoms using last round
            last_round_count = last_round_count + 1;
        else
            % Sampled a new round
            % Update value of last_round with new round
            last_round = last_round + h(k);
            % Only one atom is using the new round so far
            last_round_count = 1;
        end
    end
    
    % Iteration summary
    time(ite) = toc;
    topic_counts = sum(N,2);
    max_K_used = find(topic_counts,1,'last');
    used_topics(ite) = max_K_used;
    if calc_perpl
        if(Nperpl <= 0) % still in burn in; not calculated yet
            log_perpl(ite) = Inf;
        else 
            log_perpl(ite) = (D*log(Nperpl)-sum(lper_d))/Nwords_test;
        end
    end
    % Store sample of variables needed for prediction/likelihood
    % measurements
    post_samp{ite}.p0 = p0;
    % Difference between beta_post and beta0
    post_samp{ite}.beta_cnt = sparse(beta_post-beta0);

    % print summary
    if do_print
        fprintf('Iter %d:\n',ite);
        fprintf('\telapsed time=%f s\n', time(ite));
        fprintf('\tnum topics used=%d\n',nnz(topic_counts));
        fprintf('\tmax topic used=%d, max K_d=%d\n',max_K_used,max_K);
        fprintf('\tmax round used=%d, max H_k=%d\n',...
                sum(h(1:max_K_used)),max(H));
        fprintf('\ttopic counts: ');
        fprintf('%d ',topic_counts(1:max_K_used));fprintf('\n');
        fprintf('\trounds: ');
        fprintf('%d ',cumsum(h(1:max_K_used)));fprintf('\n');
        % latest log perplexity calculation
        if calc_perpl
            if(Nperpl <= 0)
                fprintf('\tNo log perplexity yet; still in burn-in\n');
            else
                fprintf('\tlog perplexity: %f (from %d rounds)\n',log_perpl(ite),Nperpl);
            end
        end
    end
    
    % General plotting setup
    if do_plot
        plot_sample(topic_counts,V,ite,beta_post,c,p0,p,r,opts);
    end
    
    % MCMC sample tracking: no special saving needed; just save everything
    % only save every save_step number of steps
    if(mod(ite,save_step) == 0)
        tic;
        save(save_file,'-v7.3');
        time_save = toc;
        if do_print
            fprintf('\tTime spent saving: %f s\n', time_save);
        end
    end
end
end

function H = max_round_diff(h,p0)
% MAX_ROUND_DIFF Selects maximum candidate round difference for each
% atom by sampling an auxiliary slice variable
% v_k ~ Unif(0, (1-p0_k)^h_k * xi(h_k)) and choosing the largest H_k
% s.t. (1-p0_k)^H_k * xi_{0,H_k} >= v_k
    H = floor(h + log(rand(length(h),1))./(log(1-p0)-log(1.5)));
end

function lprobs = round_diff_log_prior(last_round, last_round_count,...
                                       c0, gamma0)
% ROUND_DIFF_LOG_PRIOR Returns the log vector of unnormalized round
% difference prior probabilities p(h|last_round_count) for all
% 0 <= h <= max_diff

% Notation: In the comments below, f_{m} and F_{m} represent the pmf and
% cdf of a Pois(c0*gamma0/(c0+m)) distribution.

% Compute the Poisson parameter associated with the last used round
lambda_last = c0*gamma0/(c0+last_round);
% Compute log unnormalized probability of round_diff = 0 as
% log(1 - F_{last_round}(last_round_count))
lprob0 = log(1-poisscdf(last_round_count, lambda_last));
% Compute log(f_{last_round+h}(0)) for each candidate non-zero round
% difference
lprobs = logpoisspdf(0, c0*gamma0./(c0+last_round+(1:max_diff)));
% Compute unnormalized probability of non-zero round differences
% as log[f_{last_round}(last_round_count)*
% (1-f_{last_round+h}(0))*\prod_{g=1}^{h-1} f_{last_round+g}(0)]
lprobs = [lprob0, logpoisspdf(last_round_count,lambda_last) + ...
    log(1-exp(lprobs)) + [0,cumsum(lprobs(1:(end-1)))]];
end

function res = sample_round_diff(max_diff, last_round, last_round_count, ...
                                 c0, gamma0)
% SAMPLE_ROUND_DIFF Samples and returns a round difference res according to
% p(res = h) \propto
%   I(h <= max_diff)/xi0(h) (c0+last_round+h) p(h|last_round_count)
if max_diff == 0
    res = 0;
    return;
end
% Compute log unnormalized prior probabilities for all candidate round
% differences and rescale by log[(c0+last_round+h)/xi0(h)]
lprobs = round_diff_log_prior(max_diff,last_round,last_round_count,...
    c0,gamma0) + ...
    log(c0+last_round+(0:max_diff))-compute_log_xi(0,0:max_diff);
% Sample round difference from unnormalized probabilities
res = randsample(0:max_diff,1,true,exp(lprobs-max(lprobs)));
end

function res = sample_round(max_round, C, c0, gamma0)
% SAMPLE_ROUND Samples and returns a round m according to
% p(res = m) \propto
%   I(m <= max_round)/xi0(m) (c0+m) p(m|C)

% Notation: In the comments below, lambda_m = c0*gamma0/(c0+m), and
% F_{m} represent the cdf of a Pois(lambda_m) distribution.
if max_round == 0
    res = 0;
    return;
end
% Store the index of the last round currently used
last_round = length(C)-1;
if max_round >= last_round
    % Compute log unnormalized prior probabilities of all candidate
    % rounds greater than or equal to last_round
    lprobs = round_diff_log_prior(max_round-last_round,last_round,...
        C(end),c0,gamma0);
end
% Compute the Poisson parameter associated with the last used round
lambda_last = c0*gamma0/(c0+last_round);
% Store the largest candidate round smaller than last_round
trunc_round = min(max_round, last_round-1);
% Prepend log unnormalized probabilities of selecting any round smaller
% than last_round as
% log[(1-F_{last_round}(C_last_round-1))*lambda_m/(C_m + 1)]
lprobs = [log(1-poisscdf(C(end)-1,lambda_last))+log(c0*gamma0)-...
    log((c0+(0:trunc_round)).*(C(1:(trunc_round+1))+1)),...
    lprobs];
% Scale log unnormalized probabilities by log[(c0+m)/xi0(m)]
lprobs = lprobs + log(c0+(0:max_round))-compute_log_xi(0,0:max_round);
% Sample round from unnormalized probabilities
res = randsample(0:max_round,1,true,exp(lprobs-max(lprobs)));
end

function [log_xi_base,collapse_beta,collapse_pd_for_p0,collapse_pd_for_z,...
    calc_perpl,burn_in,perpl_step,save_step,save_file,do_print,do_plot]=...
    get_opts(opts)
% GET_OPTS For each valid opts field, returns the value contained in opts.
log_xi_base = opts.log_xi_base;
collapse_beta = opts.collapse_beta;
collapse_pd_for_p0 = opts.collapse_pd_for_p0;
collapse_pd_for_z = opts.collapse_pd_for_z;
calc_perpl = opts.calc_perpl;
burn_in = opts.burn_in;
perpl_step = opts.perpl_step;
save_step = opts.save_step;
save_file = opts.save_file;
do_print = opts.do_print;
do_plot = opts.do_plot;
end

function opts = set_default_opts(opts)
% SET_DEFAULT_OPTS Assigns a default value to each option not specified in
% opts
default.log_xi_base = log(1.5);
default.collapse_beta = false;
default.collapse_pd_for_p0 = false;
default.collapse_pd_for_z = false;
default.calc_perpl = true;
default.burn_in = 0;
default.perpl_step = 1;
default.save_step = 1;
default.save_file = 'bnb_samps_inf.mat';
default.do_print = false;
default.do_plot = false;
for option = fieldnames(default).'
    option = option{1};
    if ~isfield(opts, option)
        opts.(option) = default.(option); 
    end
end
end
