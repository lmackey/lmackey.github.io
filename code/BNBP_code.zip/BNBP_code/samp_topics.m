function [N,Z,K,K_used,beta_post,lper_d] = ...
    samp_topics(data,beta0,p0,p,r,c,N,Z,K,K_used,beta_post,lper_d,opts)
% SAMP_TOPICS Sample the topics assigned to each word of each document
%
% See NegBinMMtopic for a description of each input.
collapse_beta = opts.collapse_beta;
collapse_pd_for_p0 = opts.collapse_pd_for_p0;
collapse_pd_for_z = opts.collapse_pd_for_z;
% OR of collapse pds
collapse_pd_any = collapse_pd_for_z || collapse_pd_for_p0;
% Exponent base determining xi sequence
log_xi_base = opts.log_xi_base;

% Number of documents
D = length(data.Xid_train);

if ~collapse_beta
    % Sample topic-word parameters: beta ~ Dir(beta_post)
    betas = gamrnd(beta_post,1);
    betas = bsxfun(@rdivide,betas,sum(betas,2));
else
    % Maintain beta posterior sum over words
    beta_post_sum = sum(beta_post,2);
end
if collapse_pd_any || collapse_beta
    % Sample topics for each word of each document
    for d = 1:D
        if ~collapse_pd_for_z
            % Sample auxiliary gamma variable for each candidate topic
            % (shape-scale parameterization)
            lam = gamrnd(r(d)+N(1:K(d),d),p(1:K(d),d));
        else
            % Compute marginalized contribution of pd to topic
            % sampling probability
            lam = (N(1:K(d),d)+r(d)).*(N(1:K(d),d)+c(d)*p0(1:K(d)))./...
                (N(1:K(d),d)+1)./(N(1:K(d),d)+r(d)+c(d));
        end
        % Compute xi_d scaling terms for all candidate topics
        xi = compute_xi(d,1:K(d)).';
        for i = 1:length(data.Xid_train{d})
            % Extract the current word
            v = data.Xid_train{d}(i);
            if ~collapse_beta
                beta_v = betas(1:K(d),v);
            else
                % Compute marginalized contribution of beta to
                % topic sampling probability
                beta_v = beta_post(1:K(d),v)./beta_post_sum(1:K(d),1);
            end
            for n = 1:data.Xcnt_train{d}(i)
                % Store current topic for this word
                topic = Z{d}{i}(n);
                % Decrement topic count
                N(topic,d) = N(topic,d) - 1;
                % Decrement beta posterior
                beta_post(topic,v) = beta_post(topic,v) - 1;
                % Check if maximum used topic has changed
                if N(K_used(d),d) == 0
                    max_topic = find(N(1:K_used(d),d),1,'last');
                    if isempty(max_topic)
                        K_used(d) = 0;
                    else
                        K_used(d) = max_topic;
                    end
                end
                if collapse_pd_for_z
                    % Update lambda variable
                    lam(topic) = (N(topic,d)+r(d))*...
                        (N(topic,d)+c(d)*p0(topic))/...
                        (N(topic,d)+1)/(N(topic,d)+r(d)+c(d));
                end
                if collapse_beta
                    % Update normalized beta variable
                    beta_post_sum(topic) = beta_post_sum(topic) - 1;
                    beta_v(topic) = beta_post(topic,v)/beta_post_sum(topic);
                end
                % Sample new topic for this word
                cumprobs = cumsum(beta_v.*lam(1:K(d))./...
                    xi(max(K_used(d),1:K(d))));
                Z{d}{i}(n) = find(rand*cumprobs(end)<cumprobs,1);
                % Increment beta posterior
                beta_post(Z{d}{i}(n),v) = ...
                    beta_post(Z{d}{i}(n),v) + 1;
                if collapse_beta
                    beta_post_sum(Z{d}{i}(n)) = ...
                        beta_post_sum(Z{d}{i}(n)) + 1;
                end
                % Increment topic count
                N(Z{d}{i}(n),d) = N(Z{d}{i}(n),d) + 1;
                if collapse_pd_for_z
                    % Update lambda variable
                    lam(Z{d}{i}(n)) = (N(Z{d}{i}(n),d)+r(d))*...
                        (N(Z{d}{i}(n),d)+c(d)*p0(Z{d}{i}(n)))/...
                        (N(Z{d}{i}(n),d)+1)/(N(Z{d}{i}(n),d)+r(d)+c(d));
                end
                % Update maximum candidate topic
                K_used(d) = max(K_used(d), Z{d}{i}(n));
            end
        end
        if ~isempty(lper_d)
            % Update perplexity
            if ~collapse_beta
                lper_d(d) = update_perpl(data,lam,betas,K,d,lper_d);
            else
                lper_d(d) = update_perpl(data,lam,...
                    bsxfun(@rdivide,beta_post,beta_post_sum),K,d,lper_d);
            end
        end
        % Select maximum candidate topic for this document for the
        % next round of sampling by sampling an auxiliary slice variable
        % u_d ~ Unif(0, xi_{d,K_d_used}) and choosing the largest K_d s.t.
        % xi_{d,K_d} >= u_d
        K(d) = max_xi_index(d,rand*xi(K_used(d)),log_xi_base);
    end
else
    % Compute beta posterior
    beta_post(:,:) = beta0;
    num_topics = size(beta_post,1);
    % Sample topics for each word of each document
    for d = 1:D
        % Sample auxiliary gamma variable for each candidate topic
        % (shape-scale parameterization)
        lam = gamrnd(r(d)+N(1:K(d),d),p(1:K(d),d));
        % Reset topic counts
        N(:,d) = 0;
        % Compute xi_d scaling terms for all candidate topics
        xi = compute_xi(d,1:K(d)).';
        for i = 1:length(data.Xid_train{d})
            % Extract the current word
            v = data.Xid_train{d}(i);
            % Compute cumulative sum of unnormalized probability of each 
            % candidate topic:
            % P(topic=k) \propto beta_{k,w_di}*lam_k/xi_k
            max_topic = max(Z{d}{i});
            cumprobs = cumsum(betas(1:max_topic,v).*lam(1:max_topic)...
                ./xi(1:max_topic));
            % Sample new topics for all words
            topics = arrayfun(@(x) find(x < cumprobs,1),...
                rand(length(Z{d}{i}),1).*cumprobs(Z{d}{i}));
            % Select maximum candidate topic for each instance of this 
            % words for the next round of sampling by sampling auxiliary 
            % slice variables u_d ~ Unif(0, xi_{d,topic}) and choosing the
            % largest k s.t. xi_{d,k} >= u_d
            Z{d}{i} = max_xi_index(d,rand*xi(topics),log_xi_base);
            % Obtain counts of distinct topics
            topics = sparse(topics,1,1,num_topics,1);
            % Update beta posterior
            beta_post(:,v) = beta_post(:,v) + topics;
            % Update topic count
            N(:,d) = N(:,d) + topics;
        end
        if ~isempty(lper_d)
            % Update perplexity
            lper_d(d) = update_perpl(data,lam,betas,K,d,lper_d);
        end
        % Update maximum candidate topic
        K(d) = max(cellfun(@max, Z{d}));
    end
end

function doc_logp = update_perpl(data,lam,betas,K,d,lper_d)
% UPDATE_PERPL Update log perplexity for document d

% normalized lambda
bar_lam = lam'/sum(lam);
% calculate the log prob for this round
round_logp = 0;
for i = 1:length(data.Xid_test{d}) % unique words in the document
    % vocabulary index
    v = data.Xid_test{d}(i);
    round_logp = round_logp + data.Xcnt_test{d}(i) * ...
        log(bar_lam(1:K(d)) * betas(1:K(d),v));
end
% integrate into document summand
if isnan(lper_d(d))
    doc_logp = round_logp; % First round of perplexity calculation
else
    doc_logp = lper_d(d) + log(1 + exp(round_logp - lper_d(d)));
end