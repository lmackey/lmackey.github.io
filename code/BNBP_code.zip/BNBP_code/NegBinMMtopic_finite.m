function NegBinMMtopic_finite(Xid_train,Xcnt_train,Xid_test,Xcnt_test,K,opts)
% NEGBINMMTOPIC_FINITE performs MCMC inference for the finite approximation
% of the negative binomial topic model
%
% Example Usage (WITS):
%  K=100;
%  opts=struct('save_step',4,'save_file','WITS_bnb_samps_fin.mat', ...
%              'do_print',true); 
%  NegBinMMtopic_finite(Xid_train,Xcnt_train,Xid_test,Xcnt_test,K,opts);
%
% Example Usage (MSRC Segmentation):
%  sample_dir = '../../results/segmentation/samps/';
%  for ii=1:20
%    data_file = sprintf('MSRCv1-90_4_20_%d_sift1000hue100opp100loc100.mat',ii);
%    load(['../../extern/msrc-v1/bnbpData/',data_file]);
%    K=10;
%    symmetric_topic=true;
%    beta0=.1;
%    c0 = 3;
%    gamma0 = 3;
%    prefix = sprintf('samps-hbnbp_fin_K%d_symm%d_beta0%g_c0%g_gamma0%g-',...
%                     K,symmetric_topic,beta0,c0,gamma0);
%    opts=struct('save_step',500,'do_print',true,'calc_perpl',false,...
%      'max_iter',10000,'symmetric_topic',symmetric_topic,'beta0',beta0,...
%      'c0',c0, 'gamma0', gamma0,...
%      'labels',{[data.labels_train cell(1,length(data.Xid_test))]},...
%      'save_file',[sample_dir,prefix,data_file],...
%      'save_topic_probs',true);
%    NegBinMMtopic_finite([data.Xid_train data.Xid_test],...
%      [data.Xcnt_train data.Xcnt_test],[],[],K,opts);
%    map_topics([prefix,data_file]);
%  end
%
% Xid : Word index values. Each cell is a document and contains a
%       sequence of word indices.
% Xcnt : Word count values. Each cell corresponds to one in Xid. 
%        Xcnt{d}(n) counts the number of times word Xid{d}(n) appears in
%        document d.
% _train : training data
% _test : testing data
% K : number of topics
% opts: optional additional arguments
% ---- opts.calc_perpl : true to calculate perplexity; default true
% ---- opts.burn_in : Number of MCMC burn-in iterations (will not count
%                     for perplexity); default 0
% ---- opts.perpl_step : Number of MCMC iterations to wait between updating
%                        the perplexity calculations; default 1
% ---- opts.save_step : How many MCMC iterations between saves; default 1
% ---- opts.save_file : Where to save the MCMC samples; default 'bnb_samps_fin.mat'
% ---- opts.do_print : true to print iteration summaries; default false
% ---- opts.do_plot : true to plot summaries; default false
% ---- opts.max_iter : Maximum number of samples to take; default 10000
% ---- opts.labels : topic labels for the distinct words in each document; default {}
% ---- opts.beta0 : Prior parameter for Dirichlet distribution over
%                   topic-word parameters; default .1
% ---- opts.c0 : Concentration parameter for global beta process; default 3
% ---- opts.gamma0 : Mass parameter for global beta process; default 3
% ---- opts.symmetric_topic : true to constrain first topic to maintain symmetric
%                             distribution over words; default false
% ---- opts.save_topic_probs : true to save an estimate 'topic_probs' of the
%                              posterior probability of each distinct
%                              word in each training document
%                              belonging to each topic; default false

% Default options
calc_perpl = true;
burn_in = 0;
perpl_step = 1;
save_step = 1;
save_file = 'bnb_samps_fin.mat';
do_print = false;
do_plot = false;
max_iter = 10000;
labels = {};
symmetric_topic = false;
save_topic_probs = false;
%beta0 = 1; % Used for exploratory WITS experiment
beta0 = .1; % Used for WITS2 group identification
c0 = 3;
gamma0 = 3;
% Extract options
if isfield(opts, 'calc_perpl')
	calc_perpl = opts.calc_perpl;
end
if isfield(opts, 'burn_in')
	burn_in = opts.burn_in;
end
if isfield(opts, 'perpl_step')
	perpl_step = opts.perpl_step;
end
if isfield(opts, 'save_step')
	save_step = opts.save_step;
end
if isfield(opts, 'save_file')
	save_file = opts.save_file;
end
if isfield(opts, 'do_print')
	do_print = opts.do_print;
end
if isfield(opts, 'do_plot')
	do_plot = opts.do_plot;
end
if isfield(opts, 'max_iter')
    max_iter = opts.max_iter;
end
if isfield(opts, 'labels')
    labels = opts.labels;
end
if isfield(opts, 'symmetric_topic')
    symmetric_topic = opts.symmetric_topic;
end
if isfield(opts, 'save_topic_probs')
    save_topic_probs = opts.save_topic_probs;
end
if isfield(opts, 'beta0')
    beta0 = opts.beta0;
end
if isfield(opts, 'c0')
    c0 = opts.c0;
end
if isfield(opts, 'gamma0')
    gamma0 = opts.gamma0;
end

% Number of documents
D = length(Xid_train);
% Number of independent feature modalities
F = size(Xid_train{1},2);
% Vocabulary size (determined by largest word index)
V = zeros(1,F);
for f = 1:F
    for d = 1:D
        V(f) = max(V(f),max(Xid_train{d}(:,f)));
    end
end

% Posterior parameters for Dirichlet distribution over topic-word
% parameters
for f = 1:F
    theta_post{f} = beta0 + ones(K,V(f));
end

% Group level feature probabilities
p = .5*ones(K,D);
c = 10*ones(1,D);
% Top-level feature probabilities
p0 = ones(K,1)/K;
% Success parameters for document negative binomial distributions
r = cellfun(@sum, Xcnt_train)*(c0-1)/(c0*gamma0);

S = 75;
sig2 = 10^-4; % noise parameter for proposal jumps in MH draws for p0

% Initialize perplexity calculations
if calc_perpl
    % Will hold the summands in the log perplexity for each document
    lper_d = zeros(D,1);
    % Number of samples used for the perplexity calculation
    Nperpl = 0; 
    % Number of words in the test corpus
    Nwords_test = 0;
    for d = 1:D
        for i = 1:size(Xid_test{d},1)
            Nwords_test = Nwords_test + Xcnt_test{d}(i);
        end
    end
end

% Initialize per-word posterior topic probability estimates
topic_probs = cell(1,D);
if save_topic_probs
    for d = 1:D
        topic_probs{d} = zeros(K,size(Xid_train{d},1));
    end
end

%bool = 1;
ite = 0;
used_topics = [];
time = [];
c_all = [];
r_all = [];
p0_all = [];
lam = zeros(K,D); % Auxiliary gamma variables
N = zeros(K,D); % Topic counts for each document
while ite < max_iter
    ite = ite + 1; % MCMC iteration round
    tic;
    % All group level stuff
    % Sample topic-word parameters: theta ~ Dir(theta_post)
    for f = 1:F
        theta{f} = gamrnd(theta_post{f},1);
        if symmetric_topic
            % Constrain first topic to maintain a symmetric distribution
            % over words
            theta{f}(1,:) = 1;
        end
        theta{f} = theta{f}./repmat(sum(theta{f},2),1,V(f));
        % Reset theta posterior to prior value (initializing for update below)
        theta_post{f} = beta0 + zeros(K,V(f));
    end
    % Compute topic counts in each document
    for d = 1:D
        % Sample auxiliary gamma variable for each topic (shape-scale 
        % parameterization)
        lam(:,d) = gamrnd(r(d)+N(:,d),p(:,d));
        % Reset topic counts
        N(:,d) = 0;
        if ~isempty(labels) && ~isempty(labels{d})
            % Topic labels were provided for this document
            % iterate over each vocabulary element in the document
            for i = 1:size(Xid_train{d},1) 
                % Topic label for this word
                idx = labels{d}(i);
                % Update theta posterior
                for f = 1:F
                    theta_post{f}(idx,Xid_train{d}(i,f)) = ...
                        theta_post{f}(idx, Xid_train{d}(i,f)) + ...
                        Xcnt_train{d}(i);
                end
                % Update topic count
                N(idx,d) = N(idx,d) + Xcnt_train{d}(i);
            end
        else
            % Topic labels were not provided for this document
            % iterate over each vocabulary element in the document
            for i = 1:size(Xid_train{d},1) 
                % Compute unnormalized probabilities of each topic
                cdf = lam(:,d);
                for f = 1:F
                    cdf = cdf .* theta{f}(:,Xid_train{d}(i,f));
                end
                % Normalize and compute cumulative sum
                cdf = cumsum(cdf/sum(cdf));
                % iterate over individual word indices in the doc
                % with this vocab element value
                for n = 1:Xcnt_train{d}(i)
                    % Sample topic for this instance of this word
                    idx = find(rand<cdf,1);
                    % Update theta posterior
                    for f = 1:F
                        theta_post{f}(idx,Xid_train{d}(i,f)) = ...
                            theta_post{f}(idx, Xid_train{d}(i,f)) + 1;
                    end
                    % Update topic count
                    N(idx,d) = N(idx,d) + 1;
                end
            end
        end
        if save_topic_probs
            % Maintain estimate of the probability of each distinct word 
            % belonging to each topic
            for i = 1:size(Xid_train{d},1) 
                % Compute probability of topic under this sample
                probs = lam(:,d);
                for f = 1:F
                    probs = probs .* theta{f}(:,Xid_train{d}(i,f));
                end
                % Incoporate latest estimate into running average
                topic_probs{d}(:,i) = (ite-1)/ite*topic_probs{d}(:,i) + probs/sum(probs)/ite;
            end
        end
    end

    % perplexity calculations
    if calc_perpl && (ite > burn_in) && (mod(ite-burn_in,perpl_step)==0)
        Nperpl = Nperpl + 1;
	
        for d = 1:D
            % normalized lambda
            bar_lam = lam(:,d)'/sum(lam(:,d));
            % calculate the log prob for this round
            round_logp = 0;
            for i = 1:size(Xid_test{d},1) % unique words in the document
                                          % vocabulary index
                theta_prod = ones(size(theta{1}(:,1)));
                for f = 1:F
                    v = Xid_test{d}(i,f);
                    theta_prod = theta{f}(:,v).*theta_prod;
                end
                round_logp = round_logp + Xcnt_test{d}(i) * ...
                    log(bar_lam * theta_prod);
            end
            
            % integrate into document summand
            if Nperpl == 1
                lper_d(d) = round_logp;
            else
                lper_d(d) = lper_d(d) + log(1 + exp(round_logp - lper_d(d)));
            end
        end
    end
    
    % Sample group level feature probabilities
    p = betarnd(p0*c + N,(1-p0)*c + repmat(r,K,1));

    % Sample top level feature probabilities        
    p0 = samp_p0_mh_constant_c(p0,S,sig2,N,r,c(1),c0,gamma0,[],[]);

    % Iteration summary
    time(ite) = toc;
    topic_counts = sum(N,2);
    used_topics(ite) = nnz(topic_counts);
    if calc_perpl
        if(Nperpl <= 0) % still in burn in; not calculated yet
            log_perpl(ite) = Inf;
        else 
            log_perpl(ite) = (D*log(Nperpl)-sum(lper_d))/Nwords_test;
        end
    end
    
    % print output
    if do_print
        fprintf('Iter %d of %d:\n',ite, max_iter);
        fprintf('\tnum topics used=%d\n',used_topics(ite));
        fprintf('\ttime per iteration=%f (s)\n',time(ite));
        fprintf('\ttopic counts: ');
        fprintf('%d ',sort(topic_counts(topic_counts>0),'descend'));
        fprintf('\n');
        % latest log perplexity calculation
        if calc_perpl
            if(Nperpl <= 0)
                fprintf('\tNo log perplexity yet; still in burn-in\n');
            else
                fprintf('\tlog perplexity: %f (from %d rounds)\n',log_perpl(ite),Nperpl);
            end
        end
    end
    
    % General plotting
    if do_plot
        nfr = 3; % number of subfigure rows
        nfc = 2; % number of subfigure columns
        fi = 1; % index for each figure
        lpad = 0.12; bpad = 0.05; opad = 0.05;
        % Display the number of words assigned to each topic in descending
        % order
        mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
        [tc_vals,tc_inds] = sort(topic_counts,'descend');
        plot(tc_vals);
        xlabel('Topics ordered by usage');
        ylabel('Num words using topic');
        title(sprintf('Iteration: %d',ite));
        Kbars_side = floor(sqrt(V));
        cur_map = colormap; freezeColors; % remember current colormap
                                          % Plot of toy bars topics in the toy bar matrix
                                          % Only plot the toy bars topic output when applicable
        if(V == Kbars_side * Kbars_side)
            topic_plot = norm_topic_vals(theta_post{1}(tc_inds(tc_vals>0),:));
            mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
            colormap gray; % special colormap for now
            imlayout(1-topic_plot',...
                     [Kbars_side Kbars_side 1 size(topic_plot,1)],...
                     1-[1/Kbars_side 0]);
            title('Used topics, ordered by usage');
            freezeColors;
        else
            disp('Not toy bars data. Not plotting topics.')
        end
        % plot the p0, c, r, pd if applicable
        mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
        colormap(cur_map); % return to previous colormap
        stem(c);
        xlabel('Document index');
        ylabel('c_d');
        mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
        stem(p0(tc_inds));
        xlabel('Topics ordered by usage');
        ylabel('p0');
        mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
        stem(r);
        xlabel('Document index');
        ylabel('r_d');
        mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
        stem(p(tc_inds,1));
        xlabel('Topics ordered by usage');
        ylabel('p_{doc=1,k}');
        drawnow
    end

    % only save every save_step number of steps
    if(mod(ite,save_step) == 0)
        tic;
        save(save_file,'-v7.3');
        time_save = toc;
        if do_print
            fprintf('\tSaving samples to %s...\n', save_file);
            fprintf('\tTime spent saving: %f s\n', time_save);
        end
    end
end

function out = norm_topic_vals(topic_vals)
    % get vocab size
    Nwords = size(topic_vals,2);
    
    % normalize rows of topic_vals matrix
    sums = sum(topic_vals,2);
    out = topic_vals ./ sums(:,ones(1,Nwords));
