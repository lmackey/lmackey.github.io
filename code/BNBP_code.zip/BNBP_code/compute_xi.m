function xi = compute_xi(d, indices)
% COMPUTE_XI Returns the array of slice sampling xi variables for the
% document d and the given nonnegative integer indices
xi = exp(compute_log_xi(d, indices));
