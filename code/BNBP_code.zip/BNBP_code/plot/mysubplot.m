function mysubplot(i,j,k,m,n,o);
% most function code here borrowed from http://www.cs.berkeley.edu/~ywteh
% i: number of rows of subplots
% j: number of columns of subplots
% k: if a number, index of subplot; if a two-element array, [row col] of
% subplot
% m: padding on left side of global plot
% n: padding on bottom side of global plot
% o: internal padding

if i>0 & j>0,

 if nargin==3, m=0; end;

 if length(k)==1,
  jk = rem(k-1,j);
  ik = i-1-fix((k-1)/j);
 elseif length(k)==2,
  jk = k(2)-1;
  ik = i-(k(1));
 end;
 
 subplot('position',[jk/j+m .95*ik/i+n 1/j-m-o .95/i-n-o]);

else
 error('At least one subplot');
end;
