function plot_sample(topic_counts,V,ite,beta_post,c,p0,p,r,opts)
% PLOT_SAMPLE Gives a summary plot of a given sample

% Extract relevant options
collapse_pd_for_p0 = opts.collapse_pd_for_p0;
collapse_pd_for_z = opts.collapse_pd_for_z;
nfr = 3; % number of subfigure rows
nfc = 2; % number of subfigure columns
fi = 1; % index for each figure
lpad = 0.12; bpad = 0.05; opad = 0.05;
% Display the number of words assigned to each topic in descending
% order
mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
[tc_vals,tc_inds] = sort(topic_counts,'descend');
plot(tc_vals);
xlabel('Topics ordered by usage');
ylabel('Num words using topic');
title(sprintf('Iteration: %d',ite));
Kbars_side = floor(sqrt(V));
cur_map = colormap; freezeColors; % remember current colormap
% Plot of toy bars topics in the toy bar matrix
% Only plot the toy bars topic output when applicable
if(V == Kbars_side * Kbars_side)
    topic_plot = norm_topic_vals(beta_post(tc_inds(tc_vals>0),:));
    mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
    colormap gray; % special colormap for now
    imlayout(1-topic_plot',...
        [Kbars_side Kbars_side 1 size(topic_plot,1)],...
        1-[1/Kbars_side 0]);
    title('Used topics, ordered by usage');
    freezeColors;
else
    disp('Not toy bars data. Not plotting topics.')
end
% plot the p, c, r, pd if applicable
mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
colormap(cur_map); % return to previous colormap
stem(c);
xlabel('Document index');
ylabel('c_d');
if ~isempty(p0)
    mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
    stem(p0(tc_inds));
    xlabel('Topics ordered by usage');
    ylabel('p0');
end
mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
stem(r);
xlabel('Document index');
ylabel('r_d');
if ~collapse_pd_for_p0 || ~collapse_pd_for_z
    mysubplot(nfr,nfc,fi,lpad,bpad,opad); fi = fi + 1;
    stem(p(tc_inds,1));
    xlabel('Topics ordered by usage');
    ylabel('p_{doc=1,k}');
end
drawnow

function out = norm_topic_vals(topic_vals)
% get vocab size
Nwords = size(topic_vals,2);

% normalize rows of topic_vals matrix
sums = sum(topic_vals,2);
out = topic_vals ./ sums(:,ones(1,Nwords));

