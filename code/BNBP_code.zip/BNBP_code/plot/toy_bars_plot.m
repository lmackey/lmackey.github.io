function toy_bars_plot(topic_vals,Kside,Nplots,subplot_index,padding)
% topic_vals: matrix of (unnormalized) values to plot
% ---- each row corresponds to a topic
% ---- each column corresponds to a word in the toy bars matrix
% Kside: number of sides of toy bars matrix
% Nplots: total number of subplots
% subplot_index: index of this subplot
% padding: amount of padding in subplot

% Collect sizes
Ktopics = size(topic_vals,1);
Nwords = size(topic_vals,2);
if(Nwords ~= Kside*Kside)
    disp('Error: Number of words does not agree with toy bars matrix size')
end

% normalize rows of topic_vals matrix
sums = sum(topic_vals,2);
topic_vals = topic_vals ./ sums(:,ones(1,Nwords));

% plot the topics
colormap gray
mysubplot(Nplots,1,subplot_index,padding);
imlayout(1-topic_vals',[Kside Kside 1 Ktopics],1-[1/Kside 0]);
