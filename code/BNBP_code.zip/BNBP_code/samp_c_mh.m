function c = samp_c_mh(c, r, N, p0, p)
% SAMP_C_MH Obtain a conditional sample of the c_d variables using
% random-walk Metropolis Hastings
% p : dependence on p is integrated out whenever p is empty 

for d = 1:length(c)
    for s = 1:10
        c_prop = c(d) + sqrt(.1)*randn;
        if c_prop > 0
            % Compute the remaining terms only 
            % Certain terms will only be computed when at least one of 
            % cd*p0k or cd*p0_star_k is not nearly zero
            idx_zero = (c(d)*p0 < eps(0)) & (c_prop*p0 < eps(0));
            % Compute MH log likelihood ratio
            if isempty(p)
                % Integrate out p
                % Term: Gamma(cd)
                L = sum(gammaln(c_prop) - gammaln(c(d)));
                % Term: Gamma(rd+cd(1-p0k))
                L = L + sum(gammaln(c_prop*(1-p0)+r(d)) -...
                    gammaln(c(d)*(1-p0)+r(d)));
                % Term: 1/Gamma(Ndk+rd+cd)
                L = L + sum(gammaln(c(d)+N(:,d)+r(d)) -...
                    gammaln(c_prop+N(:,d)+r(d)));
                % Term: 1/Gamma(cd(1-p0k))
                L = L + sum(gammaln(c(d)*(1-p0)) -...
                    gammaln(c_prop*(1-p0)));
                % Term: Gamma(Ndk+cdp0k)
                L = L + sum(gammaln(c_prop*p0+idx_zero+N(:,d)) -...
                    gammaln(c(d)*p0+idx_zero+N(:,d)));
                % Term: 1/Gamma(cdp0k)
                L = L + sum(gammaln(c(d)*p0+idx_zero) -...
                    gammaln(c_prop*p0+idx_zero));
            else
                % Condition on p
                % Term: Gamma(Ndk+rd+cd)                
                L = sum(gammaln(c_prop+N(:,d)+r(d)) - ...
                    gammaln(c(d)+N(:,d)+r(d)));
                % Term: 1/Gamma(rd+cd(1-p0k))
                L = L + sum(gammaln(c(d)*(1-p0) + r(d)) - ...
                    gammaln(c_prop*(1-p0) + r(d)));
                % Term: 1/Gamma(Ndk+cdp0k)
                L = L + sum(gammaln(c(d)*p0+idx_zero+N(:,d)) - ...
                    gammaln(c_prop*p0+idx_zero+N(:,d)));
                % Term: pdk^(cdp0k) 
                L = L + (c_prop-c(d))*p0(~idx_zero)'*log(p(~idx_zero,d));
                % Term: (1-pdk)^(cd(1-p0k))
                L = L + (c_prop-c(d))*(1-p0')*log(1-p(:,d));
            end
            if rand < exp(L)
                c(d) = c_prop;
            end
        end
    end
end