function [ Z ] = aggregate_map_topics(filename);
%MAP_TOPICS Given the aggregate estimates of posterior topic belonging in
%filename compute MAP topic assignments for the words in each training
%document and save to file
%
% Example usage:
%  Z = aggregate_map_topics('samps-hbnbp_fin_K10_symm1_beta02.22045e-16-MSRCv1-90_4_20_1_sift1000hue100opp100loc100.mat');
%
%  K = 10;
%  symmetric_topic=true;
%  beta0=.1;
%  c0 = 3;
%  gamma0 = 3;
%  for ii=1:20
%    data_file = sprintf('MSRCv1-90_4_20_%d_sift1000hue100opp100loc100.mat',ii);
%    prefix = sprintf('samps-hbnbp_fin_K%d_symm%d_beta0%g_c0%g_gamma0%g-',...
%                     K,symmetric_topic,beta0,c0,gamma0);
%    aggregate_map_topics([prefix,data_file]);
%  end
%
% Input:
%  filename - Name of file storing posterior samples
%
% Output:
%  Z - Cell array; Z{d} contains topic assignments for each distinct word
%  in document d


% Load relevant variables from file
samps_dir = '../../results/segmentation/samps/';
load(fullfile(samps_dir, filename), 'D', 'Xid_train', 'topic_probs');

% Compute MAP topic assignment for each document
for d = 1:D
    % iterate over each distinct word
    for i = 1:size(Xid_train{d},1) 
        % Compute argmax topic index
        [tmp, Z{d}(i)] = max(topic_probs{d}(:,i));
    end
end
% Save loglihood to file
save_file = ['aggregate_map_topics-' filename];
preds_dir = '../../results/segmentation/preds/';
save(fullfile(preds_dir, save_file), 'Z', '-v7.3');