function [ Z ] = map_topics(filename);
%MAP_TOPICS Given the posterior samples of latent variables in filename,
%compute MAP topic assignments for the words in each training document
%and save to file
%
% Example usage:
%  Z = map_topics('samps-hbnbp_fin_beta02.22045e-16-MSRCv1-90_4_20_1_sift1000hue100opp100loc100.mat');
%
% Input:
%  filename - Name of file storing posterior samples
%
% Output:
%  Z - Cell array; Z{d} contains topic assignments for each distinct word
%  in document d


% Load relevant variables from file
samps_dir = '/work4/lmackey/neg_binom/results/segmentation/samps/';
load(fullfile(samps_dir, filename), 'F', 'D', 'Xid_train', 'Xcnt_train', 'theta', 'lam');

% Compute MAP topic assignment for each document
for d = 1:D
    % iterate over each distinct word
    for i = 1:size(Xid_train{d},1) 
        % Compute argmax topic index
        probs = lam(:,d);
        for f = 1:F
            probs = probs .* theta{f}(:,Xid_train{d}(i,f));
        end
        [tmp, Z{d}(i)] = max(probs);
    end
end
% Save loglihood to file
save_file = ['map_topics-' filename];
preds_dir = '/work4/lmackey/neg_binom/results/segmentation/preds/';
save(fullfile(preds_dir, save_file), 'Z', '-v7.3');