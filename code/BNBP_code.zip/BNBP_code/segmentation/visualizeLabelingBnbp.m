function visualizeLabelingBnbp(p, m, pSize, e, vParams, mode)
% Visualize a predicted labeling/segmentation for a set of train and test 
%  images
% Label each pixel according to the nearest patch center
% Save each image as a file according to its file name and the generating
%   method
%
% Example usage:
%  addpath(genpath('/Users/lmackey/neg_binom/src/MCMC_finite/segmentation'));
%  K = 100;
%  symmetric_topic=true;
%  beta0=.1;
%  c0 = 3;
%  gamma0 = 3;
%  for ii = 1:20
%    mode = sprintf('hbnbp_fin_K%d_symm%d_beta0%g_c0%g_gamma0%g-',...
%                     K,symmetric_topic,beta0,c0,gamma0);
%    vParams = {'sift',1000; 'hue',100; 'opp',100; 'loc',100};
%    visualizeLabelingBnbp(90,4,20,ii,vParams,mode);
%  end

% Load the corresponding data split
load(sprintf('dataSplits/dataSplit%d_%d_%d_%d.mat', p, m, pSize, e),...
    'train', 'numTrain', 'test', 'numTest');

% Load predictions
M = size(vParams,1); % Number of modalities
output = '';
for y = 1:M
    output = strcat(output, char(vParams(y,1)));
    output = strcat(output, int2str(cell2mat(vParams(y,2))));
end
filename = sprintf('aggregate_map_topics-samps-%sMSRCv1-%d_%d_%d_%d_%s',...
    mode, p, m, pSize, e, output);
load(fullfile('/Users/lmackey/neg_binom/results/segmentation/preds',...
    [filename,'.mat']), 'Z');

% Save predicted training images
saveImages([filename,'-train'], train, [Z{1:numTrain}], pSize);
% Save predicted test images
saveImages([filename,'-test'], test, [Z{numTrain+(1:numTest)}], pSize);

function saveImages(filename, train, preds, pSize)
hpSize = pSize/2;

IM = load('maps/imageMap.mat');

N = length(IM.names); % number of image files
nV = floor(IM.numRows*2/pSize)-1; % number of patch vertical values
nH = floor(IM.numCols*2/pSize)-1; % number of patch horizontal values
numPatches = nV*nH

% Load topic map
TM = load('maps/topics.mat');
colors = TM.colors;
% Find the topic ID for the void class
voidID = strmatch('void',TM.names);

% Look up table for topic colors
Tab = zeros(size(TM.names,1),3)
% Iterate backwards so that void is not overwritten
size(colors)
for i = size(colors,1):-1:1
    Tab(colors(i,4),:) = [colors(i,1),colors(i,2),colors(i,3)];
end

% Create labeled images
I = ones(nV, nH, 3);

for i = 1:length(train)
    fprintf('Image %d\n',i);
    base = (i-1)*numPatches;

    % Patch midpoints
    vCorns = (1:nV)*hpSize;
    hCorns = (1:nH)*hpSize;

    v = 1;
    h = 1;
    for n = 1:numPatches
        % Get the color corresponding to this label
        pred = preds(base+n);
        % If prediction exceeds maximum topic, set equal to void topic
        if pred > size(Tab,1)
           pred = voidID;
        end
        s1 = hpSize;
        s2 = hpSize;

        vLoc = vCorns(v);
        hLoc = hCorns(h);

        dim1 = ((vLoc-hpSize/2+1):(vLoc+hpSize/2));
        dim2 = ((hLoc-hpSize/2+1):(hLoc+hpSize/2));

        if(h == 1)
            dim2 = ((hLoc-hpSize+1):(hLoc+hpSize/2));
            s2 = 3*hpSize/2;
        end
        if(v == 1)
            dim1 = ((vLoc-hpSize+1):(vLoc+hpSize/2));
            s1 = 3*hpSize/2;
        end
        if(h == nH)
            dim2 = ((hLoc-hpSize/2+1):(hLoc+hpSize));
            s2 = 3*hpSize/2;
        end
        if(v == nV)
            dim1 = ((vLoc-hpSize/2+1):(vLoc+hpSize));
            s1 = 3*hpSize/2;
        end

        patchR = ones(s1,s2)*Tab(pred,1);
        patchG = ones(s1,s2)*Tab(pred,2);
        patchB = ones(s1,s2)*Tab(pred,3);


        I(dim1, dim2,1) = patchR;
        I(dim1,dim2,2) = patchG;
        I(dim1,dim2,3) = patchB;




        h = h + 1;
        if(h > nH)
            h = 1;
            v = v + 1;
        end
    end
    % Save image back to file
    I = uint8(I);
    axis off;
    image(I);
    axis off;
    output_dir = ...
        fullfile('/Users/lmackey/neg_binom/results/segmentation/vis/',...
        filename);
    if ~exist(output_dir,'dir')
        mkdir(output_dir);
    end
    saveas(gcf,sprintf(fullfile(output_dir,'%s'),...
        char(IM.names(train(i)))),'png');
end

