function combineImages()
%COMBINEIMAGES 
% NOTE: For best results, temporarily change line in subplot.m to 
% 'inset = [.02 .05 .02 .05];'
figDir = fullfile('..','..','notes','figs');
folders = {'seg_vis-truth','seg_vis-hbnbp'};
numFolders = length(folders);
images = {'2_21_s','3_16_s','4_5_s','5_15_s','7_19_s'};
numImages = length(images);
for ii = 1:length(folders)
    if ii == 1
        suffix = 'bmp';
    else
        suffix = 'png';
    end
    for jj = 1:numImages
        subplotMod(numFolders,numImages,(ii-1)*numImages+jj); 
        im = imread(fullfile(figDir,folders{ii},images{jj}),suffix);
        if ii == 1 && jj == 1
            im = imrotate(im,90);
        end
        image(im);
        axis off;
    end
end

