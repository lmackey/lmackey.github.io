function evalPredsBnbp(p, m, pSize, e, vParams, mode)
% Evaluate the patch-level predictions of a model on a test set 
% Write confusion matrix and total class counts to file
% Example usage:
%  addpath(genpath('/Users/lmackey/neg_binom/src/MCMC_finite/segmentation'));
%  K = 10;
%  params = [];accs = [];
%  for ii = 1:20
%    symmetric_topic=true;
%    beta0=.1;
%    c0 = 3;
%    gamma0 = 3;
%    mode = sprintf('hbnbp_fin_K%d_symm%d_beta0%g_c0%g_gamma0%g-',...
%                     K,symmetric_topic,beta0,c0,gamma0);
%    vParams = {'sift',1000; 'hue',100; 'opp',100; 'loc',100};
%    evalPredsBnbp(90,4,20,ii,vParams,mode);
%    load(sprintf('/Users/lmackey/neg_binom/results/segmentation/eval/%sResults90_4_20_%d_sift1000hue100opp100loc100.mat',mode,ii),...
%         'confusion');
%    params = [params, beta0]
%    accs = [accs, mean(diag(confusion(2:end,2:end)))]
%  end


% Load the corresponding data split
load(sprintf('dataSplits/dataSplit%d_%d_%d_%d.mat', p, m, pSize, e), 'test', 'numTest');

% Load true patch labels
load(sprintf('labels/patchLabs%d.mat', pSize), 'patchLabs', 'numPatches');

% Extract the test patch labels
testLabs = zeros(1,numTest*numPatches);

base = (1:numPatches);
for i = 1:numTest
    testLabs(1, (i-1)*numPatches + base) = ...
    patchLabs((test(i)-1)*numPatches + base, 1);
end

% Load predictions
M = size(vParams,1); % Number of modalities
output = '';
for y = 1:M
    output = strcat(output, char(vParams(y,1)));
    output = strcat(output, int2str(cell2mat(vParams(y,2))));
end
filename = sprintf('aggregate_map_topics-samps-%sMSRCv1-%d_%d_%d_%d_%s',...
    mode, p, m, pSize, e, output);
load(fullfile('/Users/lmackey/neg_binom/results/segmentation/preds',...
    [filename, '.mat']), 'Z');
preds = [Z{(end-numTest+1):end}];

% Load number of topics
load('maps/topics.mat', 'names');
nT = length(names);

% Treat predictions larger than the number of topics as void
% predictions
preds(preds > nT) = 1;

% create confusion matrix of ground truth versus predicted
[prs, gts] = meshgrid(1:nT, 1:nT);

confusion = arrayfun( @(gt,pr) sum((preds == pr) & (testLabs == gt)), gts, prs);

classCounts = sum(confusion')';

confusion = confusion ./ (classCounts*ones(1,nT));

save(sprintf('/Users/lmackey/neg_binom/results/segmentation/eval/%sResults%d_%d_%d_%d_%s.mat',...
    mode, p, m, pSize, e, output), 'confusion', 'classCounts', 'names', ...
     'mode', 'p', 'm', 'pSize', 'e', 'vParams');