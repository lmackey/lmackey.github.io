function totalConfusion(p, m, pSize, vParams, mode)
% Compute the total confusion matrix across all train-test splits for a
% given model.
% Write total confusion matrix and total class counts to file.
% Example usage:
%  addpath(genpath('/Users/lmackey/neg_binom/src/MCMC_finite/segmentation'));
%  res_path = '/Users/lmackey/neg_binom/results/segmentation/eval/';
%  K = 10;
%  symmetric_topic=true;
%  beta0s=[.1,1,eps,.1,.1,.1,.1];
%  c0s = [3,3,3,30,1.5,3,3];
%  gamma0s = [3,3,3,3,3,30,.3];
%  for ii = 1:length(beta0s)
%    beta0=beta0s(ii); c0=c0s(ii); gamma0=gamma0s(ii);
%    mode = sprintf('hbnbp_fin_K%d_symm%d_beta0%g_c0%g_gamma0%g-',...
%                   K,symmetric_topic,beta0,c0,gamma0);
%    %mode = 'LDASupGeneric';
%    vParams = {'sift',1000; 'hue',100; 'opp',100; 'loc',100};
%    totalConfusion(90,4,20,vParams,mode);
%    load(fullfile(res_path,[mode,'Results90_4_20_all_sift1000hue100opp100loc100.mat']),'confusion');
%    display(mean(diag(confusion(2:end,2:end))));
%  end
%  load('/Users/lmackey/Documents/Berkeley/Classes/Fall 07/Final project/main/results/LDASupGenericResults90_4_20_all_sift1000hue100opp100loc100.mat');


% Results path
res_path = '/Users/lmackey/neg_binom/results/segmentation/eval/';
%res_path = '/Users/lmackey/Documents/Berkeley/Classes/Fall 07/Final project/main/results';

% Process inputs
M = size(vParams,1); % Number of modalities
output = '';
for y = 1:M
    output = strcat(output, char(vParams(y,1)));
    output = strcat(output, int2str(cell2mat(vParams(y,2))));
end

% Initialize total confusion matrix and total class counts
totalConfusion = 0;
totalClassCounts = 0;
for e = 1:pSize
    inFile = fullfile(res_path, sprintf('%sResults%d_%d_%d_%d_%s.mat',...
                                    mode, p, m, pSize, e, output));
    if ~exist(inFile, 'file')
        % Compute the confusion matrix for this trial
        evalPredsBnbp(p, m, pSize, e, vParams, mode);
    end
    % Load the confusion matrix for this trial
    load(inFile, 'confusion', 'classCounts');
    % Replace NANs in confusion with zeros
    confusion(isnan(confusion)) = 0;
    % Update total confusion with rescaled confusion matrix 
    totalConfusion = totalConfusion + bsxfun(@times, confusion, classCounts);
    % Update total class counts
    totalClassCounts = totalClassCounts + classCounts;
end

% Rescale total confusion matrix
confusion = bsxfun(@rdivide, totalConfusion, totalClassCounts);
classCounts = totalClassCounts;

% Load class names
load('maps/topics.mat', 'names');

% Save results
save(fullfile(res_path, ...
              sprintf('%sResults%d_%d_%d_%s_%s.mat',...
                      mode, p, m, pSize, 'all', output)), ...
              'confusion', 'classCounts', 'names', ...
              'mode', 'p', 'm', 'pSize', 'vParams');