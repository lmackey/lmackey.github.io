##### Licensing #####

    This file is part of the BNBP code package.

    BNBP is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    BNBP is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with BNBP.  If not, see <http://www.gnu.org/licenses/>.


##### To calculate perplexity #####

1. Have some corpus in the standard format {Xid, Xcnt}.
2. Generate "training" and "testing" data, where the testing data is fraction "frac_test" of the corpus, with "divide_train_test.m". E.g. frac_test = 0.1:
>> [Xid_train,Xid_test,Xcnt_train,Xcnt_test] = divide_train_test(Xid,Xcnt,frac_test)
3. Sets opts to save, e.g., 100 subsamples of the MCMC sampler from a run with 2000 iterations and 50 burn-in iterations:
>> opts.save_samps = 100;
>> opts.burn_in = 50;
>> samps = NegBinMMtopic(Xid_train,Xcnt_train,200,2000,opts); 
4. Find the log perplexity on the test data.
>> lper = log_perplexity(samps.subsamps,Xid_test,Xcnt_test);
