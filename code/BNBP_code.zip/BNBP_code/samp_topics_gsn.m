function [N,Z,K,suff_stats] = ...
    samp_topics_gsn(data,mu0,sigma_sqd0,sigma_sqd,p,r,N,Z,K,suff_stats,opts)
% SAMP_TOPICS_GSN Sample the topic indicating the Gaussian likelihood
% associated with each example vector
%
% See BNBP for a description of all inputs.

% Exponent base determining xi sequence
log_xi_base = opts.log_xi_base;
% Number of topics
num_topics = size(suff_stats, 1);
% Number of documents
D = length(data.Xid_train);
% Observation length
V = size(suff_stats, 2) - 1;

% Posterior variance of topic-observation parameters
sigma_sqd0_post = (1/sigma_sqd0 + suff_stats(:,end)/sigma_sqd)*...
    ones(1,V);

% Sample topic-observation parameters from posterior
mus = randn(num_topics,V)./sqrt(sigma_sqd0_post) + ...
    (mu0/sigma_sqd0 + suff_stats(:,1:V)/sigma_sqd)./sigma_sqd0_post;

% Reset sufficient statistics
suff_stats(:) = 0;
% Sample topics for each observation of each document
for d = 1:D
    % Sample auxiliary gamma variable for each candidate topic
    % (shape-scale parameterization)
    lam = gamrnd(r(d)+N(1:K(d),d),p(1:K(d),d));
    % Reset topic counts
    N(:,d) = 0;
    % Compute xi_d scaling terms for all candidate topics
    xi = compute_xi(d,1:K(d)).';
    for ii = 1:length(data.Xid_train{d})
        max_topic = Z{d}{ii};
        % Extract the current observation
        v = data.Xid_train{d}(ii,:);
        % Compute log likelihood of observation under each topic
        % sum_j -(mu_{kj} - v_j)^2/sigma^2
        loglihood = ...
            -sum(bsxfun(@minus, mus(1:max_topic,:), v).^2,2)/sigma_sqd;
        % Compute likelihood under each topic rescaled by largest
        % likelihood
        likelihood = exp(loglihood-max(loglihood));
        % Compute cumulative sum of unnormalized probability of each
        % candidate topic:
        % P(topic=k) \propto likelihood*lam_k/xi_k
        cumprobs = cumsum(likelihood.*lam(1:max_topic)./xi(1:max_topic));
        % Sample new topic
        topic = find(rand*cumprobs(end) < cumprobs,1);
        % Select maximum candidate topic for the next round of sampling by
        % sampling auxiliary slice variables u_d ~ Unif(0, xi_{d,topic})
        % and choosing the largest k s.t. xi_{d,k} >= u_d
        Z{d}{ii} = max_xi_index(d,rand*xi(topic),log_xi_base);
        % Update sufficient statistics
        suff_stats(topic,:) = suff_stats(topic,:) + [v,1];
        % Update topic count
        N(topic,d) = N(topic,d) + 1;
    end
    % Update maximum candidate topic
    K(d) = max(cellfun(@max, Z{d}));
end