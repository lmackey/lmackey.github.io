function lper = log_perplexity(subsamps, Xid_test, Xcnt_test)
% LOG_PERPLEXITY Calculates log perplexity for the negative binomial process
% topic model
%
% subsamps : An array of Matlab structures representing MCMC subsamples
%            of the posterior draws from a negative binomial
%            topic model; has the following fields:
% ----- lambdas : (unnormalized) topic probabilities for the corresponding sampler rounds
%                 size D x maxK, where D = # docs, maxK = max # topics across all docs this round
% ----- betas : (normalized) word probabilities in each topic
%               size K0 x V, where K0 = max # topics allowed, V = size of vocabulary
% Xid : (withheld) test word index values. Each cell is a document and contains a
%       sequence word indices.
% Xcnt : (withheld) test count values. Each cell corresponds to one in Xid.
%        Xcnt{d}(n) counts the number of times word Xid{d}(n) appears in
%        document d.

% Number of MCMC rounds over which to average
Nrounds = length(subsamps);
% Number of documents
D = length(Xid_test);
% log perplexity output initialization; will be updated
lper = 0;
% Keep a count of the number of words in the documents
Nwords_corpus = 0;

for d = 1:D
	% initialize document-specific log probability
	for nr = 1:Nrounds
		% normalize this lambda
		bar_lam = subsamps(nr).lambdas(d,:) / sum(subsamps(nr).lambdas(d,:));
		% upper bound on number of active topics here
		K = length(bar_lam);
		round_logp = 0;
		for i = 1:length(Xid_test{d}) % unique words in the document
			% vocabulary index
			v = Xid_test{d}(i);
			round_logp = round_logp + Xcnt_test{d}(i) * ...
				log(bar_lam * subsamps(nr).betas(1:K,v));
			Nwords_corpus = Nwords_corpus + Xcnt_test{d}(i);
		end
		
		if nr == 1
			doc_logp = round_logp;
		else
			% add the round-specific logp to the total using
			% log(a+b) = log(exp(log(a)-log(b)) + 1) + log(b)
			doc_logp = log(exp(round_logp - doc_logp) + 1) + doc_logp;
		end
	end
	% normalization constant for MCMC rounds
	doc_logp = doc_logp - log(Nrounds);
	
	lper = lper + doc_logp;
end

% multiply by -1 and normalize by number of test words to get log perplexity
lper = -lper / Nwords_corpus;