function [ Xid_combo, Xcnt_combo ] = combine_docs( Xid, Xcnt )
%COMBINE_DOCS Combine multiple documents into one document
%   
% Xid : Word index values. Each cell is a document and contains a
%       sequence of word indices.
% Xcnt : Word count values. Each cell corresponds to one in Xid.
%        Xcnt{d}(n) counts the number of times word Xid{d}(n) appears in
%        document d.
% 
% Xid_combo, Xcnt_combo have the same format as Xid and Xcnt but include
% all indices and counts in a single combined document.

% Find total word counts across all documents
Xcnt_combo{1} = accumarray([Xid{:}].', [Xcnt{:}].').';
% Find indices with nonzero word counts
Xid_combo{1} = find(Xcnt_combo{1});
% Keep nonzero counts
Xcnt_combo{1} = Xcnt_combo{1}(Xid_combo{1});
end