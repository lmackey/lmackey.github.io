filename_test = '../../data/toy_lda_data.txt'
f_test = fopen(filename_test,'r');

Xid = {};
Xcnt = {};
line = fgetl(f_test);
cnt = 0;
while line ~= -1
   idx = findstr(line,':');
   % Ignore header line and documents without words
   if ~isempty(idx)
      cnt = cnt + 1;
      idx2 = findstr(line,' ');
      Xid_test{cnt} = zeros(1,length(idx));
      Xcnt_test{cnt} = zeros(1,length(idx));
      num_words = length(idx);
      for i = 1:num_words-1
         Xid_test{cnt}(i) = str2num(line(idx2(i)+1:idx(i)-1));
         Xcnt_test{cnt}(i) = str2num(line(idx(i)+1:idx2(i+1)-1));
      end
      Xid_test{cnt}(end) = str2num(line(idx2(num_words)+1:idx(end)-1));
      Xcnt_test{cnt}(end) = str2num(line(idx(end)+1:end));
   end
   line = fgetl(f_test); 
end
