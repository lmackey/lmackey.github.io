function [Xid_train,Xid_test,Xcnt_train,Xcnt_test] = ...
    divide_train_test(Xid,Xcnt,frac_test,seed)
% DIVIDE_TRAIN_TEST Divides a corpus into training and testing
% sets
%
% Example Usage:
%  [data.Xid_train,data.Xid_test,data.Xcnt_train,data.Xcnt_test]=... 
%   divide_train_test(data.Xid,data.Xcnt);
%  [data.Xid_train,data.Xid_test] = divide_train_test(data.Xid,[]);
%
% Xid : word index values. Each cell is a document and contains a
%       sequence word indices.
% Xcnt : count values. Each cell corresponds to one in Xid.
%        Xcnt{d}(n) counts the number of times word Xid{d}(n) appears in
%        document d.
% frac_test : (OPTIONAL) approximate fraction of words per document to
%             use in the test set (frac_test = .1 by default);
%             practically, will use ceiling(frac * number words in doc)
%             for each document
% seed : (OPTIONAL) seed used to initialize random number generator

if nargin < 4
    % Default seed value
    seed = 5489;
end
if nargin < 3
    % Default test fraction
    frac_test = .1;
end
% Initialize random number generator
rand('twister',seed);
randn('state',seed);

% number of documents
D = length(Xid);

% Prepare outputs
Xid_train = cell(1,D);
Xid_test = cell(1,D);
if ~isempty(Xcnt)
    Xcnt_train = cell(1,D);
    Xcnt_test = cell(1,D);
end

for d = 1:D
    % reconstruct the document
    if ~isempty(Xcnt) 
        doc = [];
        for ii = 1:length(Xid{d})
            v = Xid{d}(ii,:);
            doc = [doc; ones(Xcnt{d}(ii),1)*v];
        end
    else
        % Each observation has a multiplicity of 1
        doc = Xid{d};
    end
    
    % choose randomly which words to train and which to test
    Nd_words = length(doc);
    assignment = randsample(Nd_words,Nd_words,'false');
    
    Xid_train{d} = doc(assignment > frac_test*Nd_words,:);
    Xid_test{d} = doc(assignment <= frac_test*Nd_words,:);
        
    if ~isempty(Xcnt) 
        % fill in the training document
        [Xid_train{d},Xcnt_train{d}] = format_doc(train_doc);
        % fill in the testing document
        [Xid_test{d},Xcnt_test{d}] = format_doc(test_doc);
    end
end

end

function [Xid_tmp, Xcnt_tmp] = format_doc(doc_tmp)
% format document doc_tmp (a list of word indices) into the
% Xid, Xcnt format

uniq_words = unique(doc_tmp,'rows');
Nv = size(uniq_words,1);
M = size(uniq_words,2);
Xid_tmp = zeros(Nv,M);
Xcnt_tmp = zeros(Nv,1);
for i = 1:Nv
    % vocab element for this word
    Xid_tmp(ii,:) = uniq_words(ii,:);
    % count of this word in the document
    Xcnt_tmp(ii,:) = sum(all(bsxfun(@eq,doc_tmp,uniq_words(ii,:)),2));
end

end
