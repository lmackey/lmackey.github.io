function h = plot_word_counts( Xid, Xcnt, label, unique_labels )
%PLOT_WORD_COUNTS Display normalized word counts across documents in each
%label group
%
% Example usage:
%   load('../../data/WITS2.mat');
%   h = plot_word_counts( Xid, Xcnt, label, {'1c','2c','4c','6c','7c','8c','9c','10c','11c','12c'})
%   print(gcf,'-dpng','-r900','../../notes/WITS2_word_freq.png');
%
% Output
% h : figure handle

% Extract maximum word index
V = max(cellfun(@max, Xid));

L = length(unique_labels);

% Construct normalized word count matrix
W = zeros(V, L);
for ii = 1:L
    % Get relevant documents for this label
    docs = strcmp(label, unique_labels(ii));
    % Get word counts for this label
    W(:,ii) = accumarray([Xid{docs}].',[Xcnt{docs}],[V,1]);
end
% Prune words not used by any of the unique labels
W(all(W == 0,2), :) = [];
% Order words by total word count
totals = sum(W,2);
[tmp, order] = sort(totals,'descend');
W = W(order, :);
% Normalize by total label word count
W = bsxfun(@rdivide, W, sum(W));
% Display
figure('Position',[0 0, 1120, 420]);
num_words = 100;
pcolor([W(1:(num_words+1),:) zeros(num_words+1,1)].');
axis tight; axis ij;
%imagesc(W(1:200,:).');
%colormap(gray(256));
%colormap(1-colormap);
colorbar;
ylabel('Group ID');
xlabel('Word index');
% Remove tick marks
set(gca,'Ticklength',[0 0]);
% Set aspect ratio
daspect([1200 40000/num_words 1]);
% Force display of all tick values
set(gca,'YTick',(1:L)+.5);
set(gca,'YTickLabel',1:L);
h = gcf;
% Set paper position mode so printed image looks like that on the screen
%set(gcf, 'PaperPositionMode', 'auto');
end