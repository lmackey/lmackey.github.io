function ll = loglihood(params, post_samp, Xid, Xcnt)
% LOGLIHOOD Compute the log likelihood of the given test documents given
% samples from the posterior of an HBNBP topic model.
%
% Example usage:
%   ll = loglihood(params, post_samp, Xid, Xcnt)
%
% Inputs
% params : A struct of hyperparameters containing the following fields:
% -- c0 : Prior parameter for the top-level beta distribution
% -- gamma0 : Prior parameter for the top-level beta distribution
% -- beta0 : Prior parameter for Dirichlet distribution over topic-word
%            parameters
% post_samp : A cell array of Matlab structures representing MCMC
%             subsamples of the posterior draws from a negative binomial
%             topic model; has the following fields:
% -- beta_cnt : number of words assigned to each topic, 
%               size K0 x V, where K0 = max # topics allowed, V = size
%               of vocabulary
% -- p0 : Top-level feature probabilities, size K0 x 1, where K0 = max #
%         topics allowed
% Xid : test word index values. Each cell is a document and contains a
%            sequence of word indices.
% Xcnt : test count values. Each cell corresponds to one in Xid.
%             Xcnt{d}(n) counts the number of times word Xid{d}(n) appears
%             in document d.
% 
% Output
% ll : estimated log-likehood of each test document, size 1 x D, where D is
%      the number of test documents

% Number of MCMC rounds over which to average
Nrounds = length(post_samp);

% Number of documents
D = length(Xid);
% Cell array containing document indices
docs = num2cell(1:D);
% log likelihood output initialization; will be updated
ll = -inf(1,D);

% Compute number of words per document
N = cellfun(@sum, Xcnt);
% Failure parameters for document negative binomial distributions
r = N*(params.c0-1)/(params.c0*params.gamma0);

% Maximum test word index
V = max(cellfun(@max, Xid));
% Check if beta_cnt array must be expanded to accommodate new test words
expand = V > size(post_samp{1}.beta_cnt, 2);

tic;
for nr = 1:Nrounds
    % Expand beta_cnt to accommodate new test words if necessary
    if expand, post_samp{nr}.beta_cnt(:,V) = 0; end
    % Sample topic-word parameters: beta ~ Dir(beta_post)
    betas = gamrnd(post_samp{nr}.beta_cnt+params.beta0,1);
    betas = bsxfun(@rdivide,betas,sum(betas,2));
    % Maximum number of topics
    K0 = length(post_samp{nr}.p0);
    % Sample group level feature probabilities
    c = 10*ones(1,D); % Should match c initialization in NegBinMMtopic
    p = betarnd(post_samp{nr}.p0*c,(1-post_samp{nr}.p0)*c + repmat(r,K0,1));
    % Sample auxiliary gamma variables
    lam = gamrnd(repmat(r,K0,1),p./(1-p));
    % Compute lambda sum per document and normalize
    lam_sum = sum(lam);
    lam = bsxfun(@rdivide, lam, lam_sum);
    % Compute log likelihood contribution from this sample for each
    % document
    round_ll = logpoisspdf(N,lam_sum) + ...
        cellfun(@(d, xid, xcnt) log(lam(:,d).' * betas(:,xid)) * xcnt.',...
        docs, Xid, Xcnt);
    % Incorporate contribution into log likelihood for this document
    ll = logsumexp([ll; round_ll]);
    if mod(nr, 100) == 0
        display(mean(ll));
        fprintf('Finished %d of %d samples\n', nr, Nrounds);
        toc;
    end
end
% Incorporate normalization constant for MCMC rounds
ll = ll - log(Nrounds);

function res = logsumexp(v)
% Computes log sum exp of the columns of v
max_terms = max(v);
res = max_terms + log(sum(exp(bsxfun(@minus, v, max_terms))));