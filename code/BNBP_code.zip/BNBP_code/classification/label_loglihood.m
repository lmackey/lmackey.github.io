function [ ll ] = ...
    label_loglihood(data_name,train_label,K0,method,test_label )
%LABEL_LOGLIHOOD Compute the log likelihood of test documents under a
%topic model trained using one_label_hbnbp and save to file
%
% Example usage:
%  label_loglihood('WITS2', '1c', 200, 'hbnbp', '12c');
%  label_loglihood('WITS2', '1c', 100, 'hbnbp_finite', '12c');
%  label_loglihood('WITS2', '1c', 100, 'hdp', '12c');
%
% Inputs
% data_name : Base name of dataset to load (e.g., 'WITS2')
% train_label : Label string of the data used to train model
% K0 : Topic index parameter for trained model
% method : Which sampler used to train model: 'hbnbp', 'hbnbp_finite', or
% 'hdp'
% test_label : Label string of the test data for which log likelihood will
% be computed
%
% Output
% ll : log likelihood per test document, size 1 x D; also saved to file

method = lower(method);

% Load labeled data
data_file = ['../../data/',data_name,'.mat'];
fprintf('Loading data from %s\n', data_file);
% Creates variables 'Xid' and 'Xcnt'
load(data_file);
% Load test document ids
load_prefix = fullfile('..','..','results',[data_name,'_']);
load_file = [load_prefix,test_label,'_docs.mat'];
fprintf('Loading document indices from %s\n', load_file);
% Creates variable 'test_docs'
load(load_file);
% Load posterior samples
switch method
  case {'hdp'}
    load_file = [load_prefix,train_label,'_hdp_K',num2str(K0)];
  case {'hbnbp_finite'}
    load_file = [load_prefix,train_label,'_hbnbp_finite_K',num2str(K0)];
  otherwise
    load_file = [load_prefix,train_label,'_hbnbp_K',num2str(K0)];
end
fprintf('Loading results from %s\n', load_file);
global DistGlobals; % Required for HDP
load(load_file);
if strcmp(method, 'hdp')
    datass = npbayesr1format(Xid(test_docs),Xcnt(test_docs));
    % Remove previously unseen words in the test set
    V = max(cellfun(@max, datass));
    if V > DistGlobals{1}.dd
        for d = 1:length(datass)
            datass{d}(datass{d} > DistGlobals{1}.dd) = [];
        end
    end

    % Compute HDP log likelihood on all test documents with a given class
    % label
    % Assumes block HDP sampling
    fprintf('Running HDP topic model\n');
    ll = hdp_predict(hdp.qq0,datass,postsample,'block',hdp0.range,0,1);
    ll = meanlik(ll);
else
    % Collect loaded hyperparameters
    params = struct('gamma0',gamma0,'c0',c0,'beta0',beta0);
    % Compute HBNBP log likelihood on all test documents with a given class
    % label
    ll = loglihood(params, post_samp, Xid(test_docs), Xcnt(test_docs));
end
% Save loglihood to file
save_file = [load_file,'_loglihood_',test_label];
save(save_file, 'll', '-v7.3');