function plot_doc_lens( Xcnt, label, unique_labels, groups )
%PLOT_DOC_LENS Plot a density histogram of document lengths for each label
%category in unique_labels
%
% Example usage:
%   plot_doc_lens( Xcnt, label, {'1c','2c','4c','6c','7c','8c','9c','10c','11c','12c'}, groups);
%   print(gcf,'-depsc2','../../notes/WITS2_doc_len_hist.eps');
%
% Xcnt : 
% label : String label assigned to each document
% unique_labels : String labels for which histograms should be produced
% groups : Group names corresponding to each label integer

% Compute document lengths
doc_lens = cellfun(@sum, Xcnt);

max(doc_lens)

% Plot histograms by label
figure;
pos = get(gcf,'Position');
set(gcf,'Position',[pos(1:2),pos(3)*2.5,pos(4)]);
%set(gcf,'PaperPosition',[pos(1:2),pos(3)*2.5,pos(4)]);
hold on;
L = length(unique_labels);
m = 2;%ceil(sqrt(L));
n = ceil(L/m);
% Choose histogram bins based on range of document lengths
bins = 10:10:max(doc_lens);
for ii = 1:L
   ax(ii) = subplot(m, n, ii);
   which_doc_lens = doc_lens(strcmp(label, unique_labels(ii)));
   [f,x]=hist(which_doc_lens,bins);
   % Plot density histogram, normalized by total document count
   bar(x,f/length(which_doc_lens));
   %[f,xi] = ksdensity(which_doc_lens,'support','unbounded');
   %area(xi,f);
   title(groups(str2double(unique_labels{ii}(1:(end-1)))));
end
% Ensure subplots have the same axis limits
linkaxes(ax);
% Set paper position mode so printed image looks like that on the screen
set(gcf, 'PaperPositionMode', 'auto');
end

