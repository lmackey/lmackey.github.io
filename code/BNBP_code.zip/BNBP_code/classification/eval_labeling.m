function [ lls, classes, class_err, confusion ] = ...
    eval_labeling(data_name,label_names,K0,method)
%EVAL_LABELING Evaluate a labeling of documents induced by comparing log
%likelihoods under models trained on documents sharing a common label
%
% Example usage:
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c','3c','4c','5c','6c','7c','8c','9c','10c','11c','12c'}, 200, 'hbnbp');
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c','3c','4c','5c','6c','7c','8c','9c','10c','11c','12c'}, 100, 'hbnbp_finite');
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c','3c','4c','5c','6c','7c','8c','9c','10c','11c','12c'}, 100, 'hdp');
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c'}, 200, 'hbnbp');
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c'}, 100, 'hbnbp_finite');
%  [ lls, classes, class_err, confusion ] = eval_labeling('WITS2', {'1c','2c'}, 100, 'hdp');
%
% Inputs
% data_name : Base name of dataset to load (e.g., 'WITS2')
% label_names : Cell array of label strings to compare
% K0 : Topic index parameter for trained model
% method : Which sampler used to train model: 'hbnbp', 'hbnbp_finite', or
%  'hdp'
%
% Outputs
% lls : L x 1 cell array, where L is the number of test labels; each cell
%  contains a matrix with entries representing the log likelihood of
%  each test document under each trained model; there are L rows and a
%  number of columns equal to the number of test documents
% classes : For each test document, index of model that assigned the
%  highest likelihood
% class_err : For each test label, what fraction of documents were
%  erroneously classified
% confusion : Classification confusion matrix, with each row
%  corresponding to a single known label and each column corresponding to
%  a single predicted label
method = lower(method);

% Number of labels
L = length(label_names);

% For each test label, create a matrix of log likelihoods for each document
% under each trained model
lls = cell(L,1);

% Load log likelihood of test documents from each label under models
% trained on each label
load_prefix = fullfile('..','..','results',[data_name,'_']);
for ii = 1:L
    test_label = label_names{ii};
    for jj = 1:L
        train_label = label_names{jj};
        load_file = [load_prefix,train_label,'_',method,'_K',...
            num2str(K0),'_loglihood_',test_label];
        fprintf('Loading log likelihoods from %s\n', load_file);
        % Loads variable ll
        load(load_file); 
        if jj == 1, lls{ii} = zeros(L, length(ll)); end
        lls{ii}(jj,:) = ll;
    end
end

% Compute which model assigned the highest likelihood to each test document
classes = cellfun(@argmax, lls, 'UniformOutput', false);

% Compute classification error for each test set: 
% Fraction of documents classified incorrectly
inds = num2cell(1:L).';
class_err = cellfun(@(v,l) sum(v~=l,2)/length(v), classes, inds);

% Compute confusion matrix, with each row corresponding to a single known
% label and each column corresponding to a single predicted label
confusion = cell2mat(cellfun(@(x) accumarray(x.', 1, [L 1]).', classes, ...
                             'UniformOutput', false));

end

function I = argmax(X)
%ARGMAX Returns the arg max of each column of x
[Y,I] = max(X);
end