function latex_confusion( X, rows, cols)
% LATEX_CONFUSION Display a confusion matrix in latex table format with one 
% matrix row per table row
%
% X : confusion matrix
% rows : (OPTIONAL) cell array of row names; defaults to {'1','2',...}
% cols : (OPTIONAL) cell array of column names; empty by default

[m,n] = size(X);
if nargin < 2
    rows = arrayfun(@num2str,1:m,'UniformOutput',false);
end
if nargin < 3
    cols = [];
end
Y = zeros(m, 2*n);
Y(:,1:2:2*n) = 1-X;
Y(:,2:2:2*n) = X;

if ~isempty(cols)
    for jj = 1:n
        fprintf(['&' cols{jj}]);
    end
    fprintf('\n');
end
for ii = 1:m
    if ~isempty(rows)
        fprintf([rows{ii} ' & ']);
    end
    fprintf(' \\cellcolor[gray]{%.2f} %.2f &', Y(ii,1:(end-1)));
    fprintf(' %.2f \\\\\\cline{3-%d} &\n', Y(ii,end), n+2);
end

end

