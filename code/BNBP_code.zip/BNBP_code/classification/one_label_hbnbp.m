function one_label_hbnbp(data_name,label_name,K0,method)
% ONE_LABEL_HBNBP Run HBNBP topic model on documents matching a given label
%
% Example usage:
%  one_label_hbnbp('WITS2', '1c', 200, 'hbnbp');
%  one_label_hbnbp('WITS2', '1c', 100, 'hbnbp_finite');
%  one_label_hbnbp('WITS2', '1c', 100, 'hdp');
%
% data_name : Base name of dataset to load (e.g., 'WITS2')
% label_name : Label string to match (e.g., '1c')
% K0 : Upper bound on the largest topic index that will ever be
%      considered.
% method (OPTIONAL) : Which sampler to use: 'hbnbp', 'hbnbp_finite', or
% 'hdp'; default value is 'hbnbp'
if nargin < 4
    method = 'hbnbp';
end
method = lower(method);

% Load labeled data
data_file = ['../../data/',data_name,'.mat'];
fprintf('Loading data from %s\n', data_file);
load(data_file);
% Extract all documents with the desired label
fprintf('Extracting documents with label %s\n', label_name);
docs = find(cellfun(@(x) strcmp(x,label_name), label));
% Initialize random number generator
seed = 5849; % For repeatability
rand('twister',seed);
randn('state',seed);
% Hold out a random fraction of the documents
train_frac = .9;
train_docs = randsample(docs, round(train_frac*length(docs)));
test_docs = setdiff(docs, train_docs);
fprintf('# documents retained: %d train, %d test\n', ...
    length(train_docs), length(test_docs));
fprintf('Total training set word count: %d\n',...
    sum(cellfun(@sum,Xcnt(train_docs))));
% Save document ids
save_prefix = fullfile('..','..','results',[data_name,'_',label_name]);
save_file = [save_prefix,'_docs.mat'];
save(save_file, 'train_docs', 'test_docs', '-v7.3');
clear docs test_docs;
fprintf('Document indices saved to %s\n', save_file);
% Select save file name
switch method
  case {'hdp'}
    save_file = [save_prefix,'_hdp_K',num2str(K0)];
  case {'hbnbp_finite'}
    save_file = [save_prefix,'_hbnbp_finite_K',num2str(K0)];
  otherwise
    save_file = [save_prefix,'_hbnbp_K',num2str(K0)];
end
fprintf('Results will be saved to %s\n', save_file);
if strcmp(method, 'hdp')
    % Run an HDP experiment on all documents with a given class label
    fprintf('Running HDP topic model\n');
    datass = npbayesr1format(Xid(train_docs),Xcnt(train_docs));
    test_hdp(datass, save_file, K0);
else
    % Set options for this HBNBP experiment
    opts=struct('save_step',100,'save_file',save_file,'do_plot',false,...
                'do_print',true,'collapse_pd_for_p0',true,'calc_perpl',...
                false);
    % Run an HBNBP experiment on all documents with a given class label
    if strcmp(method, 'hbnbp_finite')
        fprintf('Running finite HBNBP topic model with %d topics\n', K0);
        NegBinMMtopic_finite(Xid(train_docs),Xcnt(train_docs),{},{},K0,opts);
    else
        fprintf('Running infinite HBNBP topic model with bound %d\n', K0);
        data.Xcnt_train = Xcnt(train_docs);
        data.Xid_train = Xid(train_docs);
        data.Xcnt_test = {};
        data.Xid_test = {};
        NegBinMMtopic(data,K0,opts);
    end
end