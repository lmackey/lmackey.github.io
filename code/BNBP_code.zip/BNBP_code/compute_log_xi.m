function log_xi = compute_log_xi(d, indices)
% COMPUTE_LOG_XI Returns the log of the array of slice sampling xi
% variables for the document d and the given nonnegative integer indices
global log_xi_base;
log_xi = -indices*log_xi_base;