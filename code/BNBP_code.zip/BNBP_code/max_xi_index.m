function k = max_xi_index(d,u,log_xi_base)
% MAX_XI_INDEX Returns a vector of nonnegative integers with k(i) the
% maximum nonnegative integer k such that u(i) <= compute_xi(d,k(i))
k = floor(-log(u)/log_xi_base);