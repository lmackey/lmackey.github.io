function p0 = samp_p0_mh(p0, S, sig2, c0, gamma0, c, r, N, p, m)
% SAMP_P0_MH Obtain a conditional sample of the p_0k variables using
% random-walk Metropolis Hastings
% p : dependence on p is integrated out whenever p is empty
% m : if m is non-empty, the size-biased sampling prior for p0 is used;
% otherwise, the finite approximation prior for p0 is used

% Number of features
K0 = length(p0);

if ~isempty(p)
   % Log odds of document probabilities
    log_pd_odds = (log(p) - log(1-p));
end

% Maintain p0*c
p0c = p0*c;

for s = 1:S
    % propose new values for p0
    p0_star = p0 + sqrt(sig2)*randn(K0,1);
    % find if proposals have gone out of frequency range and reset if
    % necessary
    idx0 = find(p0_star <= 0);
    idx1 = find(p0_star >= 1);
    p0_star(idx0) = p0(idx0);
    p0_star(idx1) = p0(idx1);
    % Maintain p0_star*c
    p0starc = p0_star*c;
    % Certain terms will only be computed when at least one of 
    % cd*p0k or cd*p0_star_k is not nearly zero
    idx_zero = (p0c < eps(0)) & (p0starc < eps(0));
    % log MH acceptance ratio
    if isempty(m)
        % Finite approximation prior term: p0^(c0*gamma0/K-1) *
        % (1-p0)^(c0*(1-gamma0/K)-1) 
        L = (c0*gamma0/K0-1)*(log(p0_star)-log(p0)) + ...
            (c0*(1-gamma0/K0)-1)*(log(1-p0_star)-log(1-p0));
    else
        % Size-biased prior term: (1-p0)^(c0+m-1)
        L = (c0+m-1).*(log(1-p0_star)-log(1-p0));
    end
    % Term contributed by: 1/Gamma(p0*c)
    L = L + sum(gammaln(p0c+idx_zero)-gammaln(p0starc+idx_zero),2);
    % Term contributed by: 1/Gamma((1-p0)*c)
    L = L + sum(gammaln((1-p0)*c)-gammaln((1-p0_star)*c),2);     
    if isempty(p)
        % Integrate out p
        % Term contributed by: Gamma(N+p0*c)
        L = L + sum(gammaln(N+p0starc+idx_zero)-...
            gammaln(N+p0c+idx_zero),2);
        % Term contributed by: Gamma(rd+(1-p0)*c)
        L = L + sum(gammaln(repmat(r,K0,1)+(1-p0_star)*c)-...
            gammaln(repmat(r,K0,1)+(1-p0)*c),2);
    else
        % Condition on p
        % Term contributed by: (pdk/(1-pdk))^(cd*p0k)
        % log(this term) is zero when both p0c and p0starc are zero
        L = L + sum((p0starc-p0c).*...
            log_pd_odds.^(~idx_zero),2);
    end
    idx_accept = (rand(K0,1) < exp(L));
    p0(idx_accept) = p0_star(idx_accept);
    % Update p0*c
    p0c(idx_accept,:) = p0starc(idx_accept,:);
end