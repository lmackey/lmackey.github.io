% LABEL_LOGLIHOOD_WRAPPER Wrapper script for LABEL_LOGLIHOOD. Reads
% train_label, test_label, and method parameters from environment variables.

% Get parameters from environment variables
train_label = getenv('TRAIN_LABEL')
method = lower(getenv('METHOD'))
test_label = getenv('TEST_LABEL')

% Select working directory and K0 based on method
switch lower(method)
case {'hbnbp'}
  cd /work4/lmackey/neg_binom/src/MCMC_finite;
  K0 = 200
case {'hbnbp_finite'}
  cd /work4/lmackey/neg_binom/src/MCMC_finite;
  K0 = 100;
otherwise
  cd /work4/lmackey/neg_binom/src/HDP;
  K0 = 100;
end
pwd

% Run startup script
startup;

% Dataset
data_name = 'WITS2'

% Run loglihood computation
label_loglihood(data_name,train_label,K0,method,test_label);

% Quit Matlab
exit;
