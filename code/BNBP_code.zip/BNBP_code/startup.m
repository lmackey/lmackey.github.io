addpath('segmentation');
addpath('data');
addpath('classification');
addpath(genpath('plot'));
addpath('../gen_data');