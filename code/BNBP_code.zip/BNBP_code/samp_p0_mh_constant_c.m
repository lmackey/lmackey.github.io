function p0 = samp_p0_mh_constant_c(p0,S,sig2,N,r,c,c0,gamma0,p,m)
% SAMP_P0_MH_CONSTANT_C Obtain a conditional sample of the p_0k variables using
% random-walk Metropolis Hastings, when c is constant across documents
% p : dependence on p is integrated out whenever p is empty 
% m : if m is non-empty, the size-biased sampling prior for p0 is used;
% otherwise, the finite approximation prior for p0 is used

[K,D] = size(N);

if ~isempty(p)
   % cd*log(pd/(1-pd)) summed across documents
   c_log_pd_odds = sum((log(p) - log(1-p)),2)*c;
end

for s = 1:S
    p0_star = p0 + sqrt(sig2)*randn(K,1);
    idx0 = find(p0_star <= 0);
    idx1 = find(p0_star >= 1);
    p0_star(idx0) = p0(idx0); 
    p0_star(idx1) = p0(idx1);
    if isempty(m)
        % Finite approximation prior term: p0^(c0*gamma0/K-1) *
        % (1-p0)^(c0*(1-gamma0/K)-1) 
        L = (c0*gamma0/K-1)*(log(p0_star)-log(p0)) + ...
            (c0*(1-gamma0/K)-1)*(log(1-p0_star)-log(1-p0));
    else
        % Size-biased prior term: (1-p0)^(c0+m-1)
        L = (c0+m-1).*(log(1-p0_star)-log(1-p0));
    end
    L = L - D*gammaln(c*p0_star) - D*gammaln(c*(1-p0_star));
    L = L + D*gammaln(c*p0) + D*gammaln(c*(1-p0));
    if isempty(p)
        % Integrate out p
        % Term contributed by: Gamma(N+p0*c) * Gamma(rd+(1-p0)*c)
        L = L + sum(gammaln(N+repmat(c*p0_star,1,D)),2) + sum(gammaln(repmat(r,K,1)+repmat(c*(1-p0_star),1,D)),2);
        L = L - sum(gammaln(N+repmat(c*p0,1,D)),2) - sum(gammaln(repmat(r,K,1)+repmat(c*(1-p0),1,D)),2);
    else
        % Condition on p
        % Term contributed by: (pdk/(1-pdk))^(cd*p0k)
        L = L + (p0_star-p0).*c_log_pd_odds;
    end
    idx_accept = find(rand(K,1) < exp(L));
    p0(idx_accept) = p0_star(idx_accept);
end