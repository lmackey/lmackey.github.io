% ONE_LABEL_HBNBP_WRAPPER Wrapper script for ONE_LABEL_HBNBP. Reads
% label_name and method parameters from environment variables.

% Get parameters from environment variables
label_name = getenv('LABEL_NAME')
method = lower(getenv('METHOD'))

% Select working directory and K0 based on method
switch lower(method)
case {'hbnbp'}
  cd /work4/lmackey/neg_binom/src/MCMC_finite;
  K0 = 200
case {'hbnbp_finite'}
  cd /work4/lmackey/neg_binom/src/MCMC_finite;
  K0 = 100;
otherwise
  cd /work4/lmackey/neg_binom/src/HDP;
  K0 = 100;
end
pwd

% Run startup script
startup;

% Dataset
data_name = 'WITS2'

% Run experiment
one_label_hbnbp(data_name, label_name, K0, method);

% Quit Matlab
exit;
